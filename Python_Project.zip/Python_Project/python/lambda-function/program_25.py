# Program 25: Sort students by marks

students = [("Amaan", 78), ("Sohan", 92), ("Adnan", 85), ("Juned", 66), ("Tahir", 88)]
result = sorted(students, key=lambda student: student[1])
print(result)
