# Program 26: Sort employees by salary

employees = [("Amaan", 45000), ("Sohan", 60000), ("Adnan", 52000), ("Juned", 48000), ("Tahir", 70000)]
result = sorted(employees, key=lambda employee: employee[1])
print(result)
