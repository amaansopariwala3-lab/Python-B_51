# Program 39: Find IT employees earning above 50,000

employees = [
    {"name": "Amaan", "department": "IT", "salary": 60000},
    {"name": "Sohan", "department": "HR", "salary": 70000},
    {"name": "Adnan", "department": "IT", "salary": 45000},
    {"name": "Juned", "department": "IT", "salary": 80000},
    {"name": "Tahir", "department": "IT", "salary": 55000}
]
result = list(filter(lambda emp: emp["department"] == "IT" and emp["salary"] > 50000, employees))
print(result)
