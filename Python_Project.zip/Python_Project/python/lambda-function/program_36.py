# Program 36: Select passed students and sort by marks

students = [("Amaan", 35), ("Sohan", 82), ("Adnan", 48), ("Juned", 29), ("Tahir", 41)]
passed = filter(lambda student: student[1] >= 35, students)
result = sorted(passed, key=lambda student: student[1])
print(result)
