# Program 29: Display the top 3 students

students = [("Amaan", 78), ("Sohan", 92), ("Adnan", 85), ("Juned", 95), ("Tahir", 81)]
top_three = sorted(students, key=lambda student: student[1], reverse=True)[:3]
print(top_three)
