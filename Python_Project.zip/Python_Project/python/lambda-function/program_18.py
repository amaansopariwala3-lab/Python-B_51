# Program 18: Find names starting with A

names = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
result = list(filter(lambda name: name.startswith("A"), names))
print(result)
