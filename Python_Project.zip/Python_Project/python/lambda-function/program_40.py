# Program 40: Rank students from highest to lowest marks

students = [("Amaan", 78), ("Sohan", 92), ("Adnan", 85), ("Juned", 95), ("Tahir", 81)]
ranking = sorted(students, key=lambda student: student[1], reverse=True)
for rank, (name, marks) in enumerate(ranking, start=1):
    print(f"Rank {rank}: {name} - {marks} marks")
