# Program 24: Sort names by their length

names = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
result = sorted(names, key=lambda name: len(name))
print(result)
