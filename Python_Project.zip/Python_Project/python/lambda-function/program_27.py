# Program 27: Sort student records by marks

students = [
    {"name": "Amaan", "marks": 78},
    {"name": "Sohan", "marks": 92},
    {"name": "Adnan", "marks": 85},
    {"name": "Juned", "marks": 66},
    {"name": "Tahir", "marks": 88}
]
result = sorted(students, key=lambda student: student["marks"])
print(result)
