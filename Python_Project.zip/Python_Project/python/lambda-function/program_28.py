# Program 28: Find employees earning above 50,000

employees = [
    {"name": "Amaan", "salary": 45000},
    {"name": "Sohan", "salary": 60000},
    {"name": "Adnan", "salary": 75000},
    {"name": "Juned", "salary": 38000},
    {"name": "Tahir", "salary": 52000}
]
result = list(filter(lambda employee: employee["salary"] > 50000, employees))
print(result)
