# Dictionary Program 2
emp = {101: "Amaan", 102: "Sohan", 103: "Adnan", 104: "Juned", 105: "Tahir"}
print("Total employees:", len(emp))
