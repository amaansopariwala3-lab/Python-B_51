# List Program 3
L1 = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
L1.append("Amaan")
print(L1)
