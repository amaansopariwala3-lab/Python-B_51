# Dictionary Program 3
emp = {101: "Amaan", 102: "Sohan", 103: "Adnan", 104: "Juned", 105: "Tahir"}
ids = list(emp.keys())
for i in emp:
    print(i)
print(ids)
