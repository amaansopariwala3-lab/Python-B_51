# List Program 1
L1 = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
print(L1)
