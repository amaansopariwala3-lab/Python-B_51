# Tuple Program 1
t1 = ("Amaan", "Sohan", "Adnan", "Juned", "Tahir")
print(t1)
