# List Program 15
L1 = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
L1.append("Amaan")
for s in L1:
    if 'a' in s.lower():
        print(s)
