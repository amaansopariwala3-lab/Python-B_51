# Dictionary Program 5
emp = {101: "Amaan", 102: "Sohan", 103: "Adnan", 104: "Juned", 105: "Tahir"}
eid = int(input("Enter employee ID: "))
if eid in emp:
    print("Employee is present")
else:
    print("Employee is not present")
