# List Program 9
# Friends: Amaan, Sohan, Adnan, Juned, Tahir (use these names when entering input)
L1 = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
L1.append("Amaan")
name = input("Enter name to remove: ")
while name in L1:
    L1.remove(name)
print(L1)
