# List Program 13
# Friends: Amaan, Sohan, Adnan, Juned, Tahir (use these names when entering input)
employees = [["Amaan", 25, 30000, "Python"],
             ["Sohan", 30, 45000, "Java"],
             ["Adnan", 28, 40000, "Web Design"],
             ["Juned", 26, 35000, "C++"],
             ["Tahir", 29, 50000, "Data Science"]]
name = input("Enter employee name: ")
found = False
for emp in employees:
    if emp[0] == name:
        print("Name:", emp[0])
        print("Age:", emp[1])
        print("Salary:", emp[2])
        print("Expertise:", emp[3])
        found = True
if found == False:
    print("Error: Employee not found")
