# Dictionary Program 4
emp = {101: "Amaan", 102: "Sohan", 103: "Adnan", 104: "Juned", 105: "Tahir"}
names = list(emp.values())
for n in emp.values():
    print(n)
print(names)
