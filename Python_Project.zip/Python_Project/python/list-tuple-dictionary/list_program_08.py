# List Program 8
# Friends: Amaan, Sohan, Adnan, Juned, Tahir (use these names when entering input)
L1 = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
L1.append("Amaan")
name = input("Enter name to remove: ")
if name in L1:
    L1.remove(name)
    print(L1)
else:
    print("Student not found")
