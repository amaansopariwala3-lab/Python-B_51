# Dictionary Program 7
emp = {101: "Amaan", 102: "Sohan", 103: "Adnan", 104: "Juned", 105: "Tahir"}
eid = int(input("Enter employee ID: "))
if eid in emp:
    emp[eid] = input("Enter new name: ")
    print(emp)
else:
    print("Employee not found")
