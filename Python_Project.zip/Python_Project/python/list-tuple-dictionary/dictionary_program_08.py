# Dictionary Program 8
emp = {101: "Amaan", 102: "Sohan", 103: "Adnan", 104: "Juned", 105: "Tahir"}
eid = int(input("Enter employee ID to remove: "))
if eid in emp:
    emp.pop(eid)
    print(emp)
else:
    print("Employee not found")
