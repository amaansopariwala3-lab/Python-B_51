# List Program 6
# Friends: Amaan, Sohan, Adnan, Juned, Tahir (use these names when entering input)
L1 = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
L1.append("Amaan")
name = input("Enter student name: ")
if name in L1:
    print("Total same name students:", L1.count(name))
    print("Position of first occurrence:", L1.index(name))
else:
    print("Student is not present")
