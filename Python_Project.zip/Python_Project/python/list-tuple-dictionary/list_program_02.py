# List Program 2
L1 = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
print("Total number of students:", len(L1))
