# List Program 5
# Friends: Amaan, Sohan, Adnan, Juned, Tahir (use these names when entering input)
L1 = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
L1.append("Amaan")
name = input("Enter student name: ")
if name in L1:
    print("Student is present")
else:
    print("Student is not present")
