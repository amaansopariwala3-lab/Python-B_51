# Dictionary Program 6
emp = {101: "Amaan", 102: "Sohan", 103: "Adnan", 104: "Juned", 105: "Tahir"}
eid = int(input("Enter employee ID: "))
if eid in emp:
    print("Name:", emp[eid])
else:
    name = input("Not available. Enter employee name: ")
    emp[eid] = name
    print(emp)
