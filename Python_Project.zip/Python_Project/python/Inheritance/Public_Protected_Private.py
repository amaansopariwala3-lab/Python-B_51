class Student:
    college = "LJ University"  # Public class variable

    def __init__(self, name="Amaan"):
        self.name = name          # Public variable
        self._marks = 85          # Protected variable
        self.__password = "1234"  # Private variable

    def display(self):
        print("Name:", self.name)
        print("Marks:", self._marks)
        print("Password:", self.__password)



friends = ["Amaan", "Sohan", "Adnan", "Juned", "Tahir"]
s1 = Student(friends[0])

print("Name:", s1.name)
print("Marks:", s1._marks)
print("College:", s1.college)

s1.display()

print("\nAll friends:")
for f in friends:
    Student(f).display()
