# Friends: Amaan, Sohan, Adnan, Juned, Tahir (use these names when entering input)
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display_person(self):
        print("Name:", self.name)
        print("Age:", self.age)


class Student(Person):
    def __init__(self, name, age, roll_no, marks):
        super().__init__(name, age)
        self.roll_no = roll_no
        self.marks = marks

    def display_student(self):
        self.display_person()
        print("Roll No:", self.roll_no)
        print("Marks:", self.marks)



name = input("Enter student name: ")
age = int(input("Enter student age: "))
roll_no = int(input("Enter roll number: "))
marks = float(input("Enter student marks: "))


s1 = Student(name, age, roll_no, marks)


print("\n--- Student Details ---")
s1.display_student()