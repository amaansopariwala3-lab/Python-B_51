
class Employee:
    def __init__(self, emp_id, name, basic_salary):
        self.emp_id = emp_id
        self.name = name
        self.basic_salary = basic_salary
        self.hra = 0
        self.da = 0
        self.pf = 0
        self.net_salary = 0

    def calculate_salary(self):
        self.hra = self.basic_salary * 0.20
        self.da = self.basic_salary * 0.10
        self.pf = self.basic_salary * 0.12

        self.net_salary = (
            self.basic_salary + self.hra + self.da - self.pf
        )

    def display(self):
        print("Employee ID  :", self.emp_id)
        print("Name         :", self.name)
        print("Basic Salary :", self.basic_salary)
        print("HRA          :", self.hra)
        print("DA           :", self.da)
        print("PF           :", self.pf)
        print("Net Salary   :", self.net_salary)
