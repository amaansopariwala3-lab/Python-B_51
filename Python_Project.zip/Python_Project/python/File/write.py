# Friends: Amaan, Sohan, Adnan, Juned, Tahir (use these names when entering input)

with open("employee.txt", "w") as f:
    f.write("Employee Salary Management\n")
    f.write("Employee ID: " + input("Enter Employee ID: ") + "\n")
    f.write("Name: " + input("Enter Employee Name: ") + "\n")
    f.write("Basic Salary: " + input("Enter Basic Salary: ") + "\n")

print("File created successfully!")
