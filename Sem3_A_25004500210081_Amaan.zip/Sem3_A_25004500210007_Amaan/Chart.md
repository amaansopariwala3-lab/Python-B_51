# PTMAE — Program Flow Chart

**Student:** Amaan Sopariwala | **Roll No.:** 51

## 1. Overall program flow

```mermaid
flowchart TD
    A([Start: python main.py]) --> B[run_demonstrations]
    B --> U1[Unit 1: compound_interest, calculate_penalty, trajectory_guard]
    U1 --> U2[Unit 2: parse_raw_log_line, create_audit_filter, build_positional_filters]
    U2 --> U3[Unit 3: build_reverse_index, clean_transaction_queue]
    U3 --> U4[Unit 4: update_account_record]
    U4 --> U5[Unit 5: Account classes and execute_batch_settlement]
    U5 --> C{Start CLI? YES / Enter}
    C -- YES --> CLI[run_banking_cli]
    C -- Enter --> Z([End])
    CLI --> Z
```

## 2. Banking CLI flow

```mermaid
flowchart TD
    S([PTMAE> prompt]) --> I[Read command]
    I --> D{Command?}
    D -- INTEREST --> P1[Read principal, rate, periods] --> V1{Valid and non-negative?}
    V1 -- No --> P1
    V1 -- Yes --> R1[Print compound interest] --> S
    D -- PENALTY --> P2[Read amount and rate] --> R2[Print penalty fee] --> S
    D -- GUARD --> R3[Run trajectory_guard demo] --> S
    D -- HELP --> R4[Show commands] --> S
    D -- Empty / Unknown --> R5[Show message] --> S
    D -- EXIT --> E([Quit])
```

## 3. Trajectory guard flow

```mermaid
flowchart TD
    A([Start: balance = starting_balance]) --> B{More transactions?}
    B -- No --> F([Return balance, history])
    B -- Yes --> C{Termination flag OR balance < threshold?}
    C -- Yes --> H[Print stop message] --> F
    C -- No --> D[balance = balance + amount; save to history] --> B
```

## 4. File update flow (update_account_record)

```mermaid
flowchart TD
    A([Open accounts.db in r+ mode]) --> B[Read next line]
    B --> C{End of file?}
    C -- Yes --> Z[Print processed / rejected counts] --> E([End])
    C -- No --> D[Parse and validate record]
    D --> V{Valid?}
    V -- No --> L[Write to corrupted.log] --> B
    V -- Yes --> M{ID matches target?}
    M -- No --> B
    M -- Yes --> N{new_balance >= 0?}
    N -- No --> L
    N -- Yes --> O[Shift file tail if length changed] --> W[Write new record + truncate]
    W --> G[Append to ledger.txt] --> B
```

## 5. Settlement flow (Unit 5)

```mermaid
flowchart TD
    A([execute_batch_settlement]) --> B[Next account]
    B --> T{Account type}
    T -- Savings --> S1{Balance after >= 1000?}
    T -- Current --> S2{Balance after >= -overdraft limit?}
    T -- Credit --> S3{Used credit + 2.5% surcharge <= limit?}
    S1 -- Yes --> OK[SUCCESS]
    S2 -- Yes --> OK
    S3 -- Yes --> OK
    S1 -- No --> FL[FAILED: InsufficientBalanceError]
    S2 -- No --> FL
    S3 -- No --> FL
    OK --> N{More accounts?}
    FL --> N
    N -- Yes --> B
    N -- No --> Sum([Print batch summary])
```
