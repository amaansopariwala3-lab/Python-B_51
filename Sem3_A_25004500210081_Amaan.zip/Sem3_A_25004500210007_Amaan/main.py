"""PTMAE - Pure Python Transactional Micro-Banking & Audit Engine.
Student: Amaan Sopariwala | Roll No.: 51
Python 3.x; only the datetime module is imported.
"""

from datetime import datetime

STUDENT_NAME = "Amaan Sopariwala"
ROLL_NO = 51
SAFETY_THRESHOLD = 1000.0


# ============================================================
# UNIT 1: STATE CONTROL ENGINE AND TRAJECTORY GUARDS
# ============================================================
def compound_interest(principal, rate_percent, periods):
    """Calculate compound interest using arithmetic and a loop."""
    amount = principal
    period = 0
    while period < periods:
        amount = amount + (amount * rate_percent / 100)
        period = period + 1
    return amount - principal


def calculate_penalty(amount, penalty_rate_percent):
    """Calculate a penalty using arithmetic operators only."""
    return amount * penalty_rate_percent / 100


def trajectory_guard(transactions, starting_balance, threshold=SAFETY_THRESHOLD):
    """Process transactions and stop on a low balance or termination flag."""
    balance = starting_balance
    processed = []
    index = 0
    while index < len(transactions):
        item = transactions[index]
        # Short-circuit evaluation checks termination before applying amount.
        if item[1] or balance < threshold:
            print("Trajectory guard stopped at transaction", index + 1)
            break
        balance = balance + item[0]
        processed.append(balance)
        index = index + 1
    return balance, processed


def run_banking_cli():
    """Run a nested while-loop command interface until EXIT is entered."""
    print("\nPTMAE Banking CLI | Student:", STUDENT_NAME, "| Roll No.:", ROLL_NO)
    print("Commands: INTEREST, PENALTY, GUARD, HELP, EXIT")
    running = True
    while running:
        command = input("PTMAE> ").strip().upper()
        if command == "EXIT":
            running = False
        elif command == "HELP":
            print("INTEREST = compound interest; PENALTY = penalty fee; GUARD = safety demo; EXIT = quit")
        elif command == "INTEREST":
            valid = False
            while not valid:
                try:
                    principal = float(input("Principal amount: "))
                    rate = float(input("Annual rate (%): "))
                    periods = int(input("Number of periods: "))
                    if principal < 0 or rate < 0 or periods < 0:
                        print("Values must be non-negative.")
                    else:
                        valid = True
                        print("Compound interest:", round(compound_interest(principal, rate, periods), 2))
                except ValueError:
                    print("Invalid number. Please try again.")
        elif command == "PENALTY":
            try:
                amount = float(input("Overdue amount: "))
                rate = float(input("Penalty rate (%): "))
                if amount < 0 or rate < 0:
                    print("Values must be non-negative.")
                else:
                    print("Penalty fee:", round(calculate_penalty(amount, rate), 2))
            except ValueError:
                print("Invalid number. Please try again.")
        elif command == "GUARD":
            transactions = [(500.0, False), (-200.0, False), (-900.0, False), (100.0, True)]
            final_balance, history = trajectory_guard(transactions, 1800.0)
            print("Final balance:", final_balance, "| Balances:", history)
        elif command == "":
            print("Please enter a command.")
        else:
            print("Unknown command. Enter HELP to see commands.")


# ============================================================
# UNIT 2: NATIVE LOG PARSER AND CLOSURE MECHANICS
# ============================================================
def parse_raw_log_line(line, delimiter=",", quote_char='"'):
    """Parse a delimited line manually, supporting quoted and escaped quotes."""
    tokens = []
    field = ""
    inside_quotes = False
    index = 0
    while index < len(line):
        char = line[index]
        if char == quote_char:
            if inside_quotes and index + 1 < len(line) and line[index + 1] == quote_char:
                field = field + quote_char
                index = index + 1
            else:
                inside_quotes = not inside_quotes
        elif char == delimiter and not inside_quotes:
            tokens.append(field.strip())
            field = ""
        else:
            field = field + char
        index = index + 1
    tokens.append(field.strip())
    return tokens


def create_audit_filter(threshold):
    """Return a validator closure that counts audited records with nonlocal."""
    audited_count = 0

    def validate(record):
        nonlocal audited_count
        audited_count = audited_count + 1
        try:
            amount = float(record[2])
            return amount >= threshold
        except (ValueError, IndexError, TypeError):
            return False

    validate.get_count = lambda: audited_count
    return validate


def build_positional_filters(criteria):
    """Build lambdas that test a position, binding each position with k=k."""
    filters = []
    k = 0
    while k < len(criteria):
        expected = criteria[k]
        filters.append(lambda row, k=k, expected=expected: len(row) > k and row[k] == expected)
        k = k + 1
    return filters


# ============================================================
# UNIT 3: DATA INVERSION AND IN-PLACE PROCESSING
# ============================================================
def build_reverse_index(raw_db):
    """Map each service tag to sorted unique (account, branch) tuples."""
    reverse_index = {
        tag: sorted(set((account_id, branch_id)
                        for branch_id, entries in raw_db.items()
                        for account_id, tags in entries
                        for service in tags if service == tag))
        for tag in {service for entries in raw_db.values() for account_id, tags in entries for service in tags}
    }
    return reverse_index


def clean_transaction_queue(data_list):
    """Clean queue elements in place without rebinding the top-level list."""
    index = 0
    while index < len(data_list):
        item = data_list[index]
        if isinstance(item, tuple):
            data_list[index] = list(item)
            item = data_list[index]
        if isinstance(item, set):
            evens = set()
            for value in item:
                if isinstance(value, int) and value % 2 == 0:
                    evens.add(value)
            data_list[index] = item - evens
            item = data_list[index]
        if isinstance(item, list):
            item.sort(reverse=True)
        index = index + 1

    # Remove duplicate primitive values by scanning/deleting from this same list.
    index = 0
    while index < len(data_list):
        current = data_list[index]
        if isinstance(current, (str, int, float, bool)):
            later = index + 1
            while later < len(data_list):
                if type(data_list[later]) == type(current) and data_list[later] == current:
                    del data_list[later]
                else:
                    later = later + 1
        index = index + 1
    return data_list


# ============================================================
# UNIT 4: TRANSACTIONAL FILE MODIFIER AND ERROR LOGGER
# ============================================================
class BaseSystemError(Exception):
    """Base exception for PTMAE system errors."""
    pass


class CorruptedRecordError(BaseSystemError):
    """Raised when an account record cannot be parsed or validated."""
    pass


class OutOfBoundsError(BaseSystemError):
    """Raised when an amount or balance exceeds an allowed boundary."""
    pass


class InsufficientBalanceError(BaseSystemError):
    """Raised when an account cannot cover a requested settlement."""
    pass


def ensure_demo_files():
    """Create accounts.db only when it does not already exist."""
    try:
        with open("accounts.db", "r", encoding="utf-8") as source:
            source.read(1)
    except FileNotFoundError:
        with open("accounts.db", "w", encoding="utf-8") as target:
            target.write("Acc101,SAVINGS,5200.00\n")
            target.write("Acc102,CURRENT,800.00\n")
            target.write("Acc103,CREDIT,2500.00\n")
            target.write("BROKEN,REALLY_BAD\n")


def _shift_file_tail(file_obj, start_position, delta):
    """Shift file content from start_position by delta using chunked passes."""
    file_obj.seek(0, 2)
    end_position = file_obj.tell()
    chunk_size = 256
    if delta > 0:
        # Extend the file by delta characters before copying backward.
        if end_position > 0:
            file_obj.seek(end_position - 1)
            last_char = file_obj.read(1)
            file_obj.seek(end_position + delta - 1)
            file_obj.write(last_char if last_char else " ")
        else:
            file_obj.seek(delta - 1)
            file_obj.write(" ")
        read_end = end_position
        while read_end > start_position:
            read_start = read_end - chunk_size
            if read_start < start_position:
                read_start = start_position
            file_obj.seek(read_start)
            chunk = file_obj.read(read_end - read_start)
            file_obj.seek(read_start + delta)
            file_obj.write(chunk)
            read_end = read_start
        file_obj.seek(0, 2)
        file_obj.truncate(file_obj.tell())
    elif delta < 0:
        read_start = start_position
        while read_start < end_position:
            file_obj.seek(read_start)
            chunk = file_obj.read(chunk_size)
            if chunk == "":
                break
            file_obj.seek(read_start + delta)
            file_obj.write(chunk)
            read_start = read_start + len(chunk)
        file_obj.truncate(end_position + delta)


def update_account_record(account_id, new_balance):
    """Update one record in r+ mode and preserve all neighboring records."""
    ensure_demo_files()
    processed = 0
    rejected = 0
    line_number = 0
    try:
        with open("accounts.db", "r+", encoding="utf-8", newline="") as file_obj:
            while True:
                record_start = file_obj.tell()
                line = file_obj.readline()
                if line == "":
                    break
                line_number = line_number + 1
                processed = processed + 1
                try:
                    fields = parse_raw_log_line(line.rstrip("\n"))
                    if len(fields) != 3:
                        raise CorruptedRecordError("wrong field count")
                    record_id = fields[0]
                    account_type = fields[1].upper()
                    try:
                        balance = float(fields[2])
                    except ValueError:
                        raise CorruptedRecordError("balance is not numeric")
                    if account_type not in ("SAVINGS", "CURRENT", "CREDIT"):
                        raise CorruptedRecordError("unknown account type")
                    if record_id == account_id:
                        if new_balance < 0:
                            raise OutOfBoundsError("balance cannot be negative")
                        old_end = file_obj.tell()
                        old_record = line
                        newline = "\n" if old_record.endswith("\n") else ""
                        new_record = record_id + "," + account_type + "," + format(new_balance, ".2f") + newline
                        delta = len(new_record) - len(old_record)
                        _shift_file_tail(file_obj, old_end, delta)
                        file_obj.seek(record_start)
                        file_obj.write(new_record)
                        file_obj.flush()
                        with open("ledger.txt", "a", encoding="utf-8") as ledger:
                            ledger.write(datetime.now().strftime("%Y-%m-%d %H:%M:%S") +
                                         " | UPDATED | line=" + str(line_number) +
                                         " | account=" + record_id + " | balance=" + format(new_balance, ".2f") + "\n")
                        # After shifting, continue from the end of the newly written record.
                        file_obj.seek(record_start + len(new_record))
                    else:
                        file_obj.seek(record_start + len(line))
                except (CorruptedRecordError, OutOfBoundsError, ValueError, IndexError) as error:
                    rejected = rejected + 1
                    with open("corrupted.log", "a", encoding="utf-8") as log_file:
                        log_file.write("line=" + str(line_number) + " | " + str(error) + " | " + line.rstrip("\n") + "\n")
                else:
                    pass
                finally:
                    # Per-record cleanup hook; counts are printed after all records.
                    pass
    except OSError as error:
        print("File operation error:", error)
    finally:
        print("File processing complete. Processed:", processed, "Rejected:", rejected)


# ============================================================
# UNIT 5: OBJECT-ORIENTED AND POLYMORPHIC SETTLEMENT ENGINE
# ============================================================
class Account:
    """Base account with private balance and protected account identifier."""
    total_accounts = 0

    def __init__(self, account_id, balance):
        """Validate and initialise account information."""
        if not isinstance(account_id, str):
            raise TypeError("account_id must be a string")
        if not isinstance(balance, (int, float)) or isinstance(balance, bool):
            raise TypeError("balance must be numeric")
        if balance < 0:
            raise OutOfBoundsError("initial balance cannot be negative")
        self._account_id = account_id
        self.__balance = float(balance)
        Account.total_accounts = Account.total_accounts + 1

    def get_balance(self):
        """Return the private balance."""
        return self.__balance

    def set_balance(self, value):
        """Set balance after validating its type and range."""
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError("balance must be numeric")
        if value < 0:
            raise OutOfBoundsError("balance cannot be negative")
        self.__balance = float(value)

    def get_account_id(self):
        """Return the account identifier."""
        return self._account_id

    def process_settlement(self, amount):
        """Base settlement method, overridden by subclasses."""
        raise NotImplementedError("Subclass must implement settlement")


class SavingsAccount(Account):
    """Savings account that maintains a minimum balance of 1000."""
    def __init__(self, account_id, balance):
        """Initialise a savings account."""
        super().__init__(account_id, balance)

    def process_settlement(self, amount):
        """Deduct amount unless it would breach the minimum balance."""
        if amount <= 0:
            raise OutOfBoundsError("settlement amount must be positive")
        remaining = self.get_balance() - amount
        if remaining < 1000:
            raise InsufficientBalanceError("savings minimum balance is 1000")
        self.set_balance(remaining)
        return self.get_balance()


class CurrentAccount(Account):
    """Current account that permits overdraft up to its private limit."""
    def __init__(self, account_id, balance, overdraft_limit=2000.0):
        """Initialise current account and private overdraft limit."""
        super().__init__(account_id, balance)
        if not isinstance(overdraft_limit, (int, float)) or overdraft_limit < 0:
            raise OutOfBoundsError("overdraft limit must be non-negative")
        self.__overdraft_limit = float(overdraft_limit)
        self.__current_balance = float(balance)

    def get_balance(self):
        """Return current-account balance, including a negative overdraft."""
        return self.__current_balance

    def set_balance(self, value):
        """Set current-account balance within the overdraft boundary."""
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError("balance must be numeric")
        if value < -self.__overdraft_limit:
            raise OutOfBoundsError("balance exceeds overdraft limit")
        self.__current_balance = float(value)

    def process_settlement(self, amount):
        """Deduct amount while respecting the overdraft limit."""
        if amount <= 0:
            raise OutOfBoundsError("settlement amount must be positive")
        remaining = self.get_balance() - amount
        if remaining < -self.__overdraft_limit:
            raise InsufficientBalanceError("overdraft limit exceeded")
        self.set_balance(remaining)
        return self.get_balance()


class CreditAccount(Account):
    """Credit account that applies a 2.5 percent surcharge."""
    def __init__(self, account_id, balance, credit_limit=5000.0):
        """Initialise credit account and credit limit."""
        super().__init__(account_id, balance)
        self.__credit_limit = float(credit_limit)
        self.__credit_used = float(balance)

    def process_settlement(self, amount):
        """Apply surcharge and ensure total used credit remains in limit."""
        if amount <= 0:
            raise OutOfBoundsError("settlement amount must be positive")
        charged_amount = amount + amount * 2.5 / 100
        new_used = self.__credit_used + charged_amount
        if new_used > self.__credit_limit:
            raise InsufficientBalanceError("credit limit exceeded")
        self.__credit_used = new_used
        self.set_balance(new_used)
        return charged_amount


def execute_batch_settlement(account_list, transaction_amount):
    """Settle each account independently so one failure does not stop others."""
    successes = 0
    failures = 0
    for account in account_list:
        try:
            result = account.process_settlement(transaction_amount)
            successes = successes + 1
            print("SUCCESS", account.get_account_id(), "result:", round(result, 2))
        except (BaseSystemError, TypeError, ValueError, NotImplementedError) as error:
            failures = failures + 1
            print("FAILED", account.get_account_id(), "reason:", error)
    print("Batch summary: successes =", successes, "failures =", failures)
    return successes, failures


# ============================================================
# DEMONSTRATION CODE: EXERCISE ALL REQUIRED FEATURES
# ============================================================
def run_demonstrations():
    """Run visible demonstrations for the main SRS requirements."""
    print("=" * 64)
    print("PTMAE DEMONSTRATION | Name:", STUDENT_NAME, "| Roll No.:", ROLL_NO)
    print("=" * 64)

    print("\n[UNIT 1] Interest and penalty")
    print("Interest on 1000 at 5% for 2 periods:", round(compound_interest(1000, 5, 2), 2))
    print("Penalty on 500 at 2%:", round(calculate_penalty(500, 2), 2))
    print("Interest test 2:", round(compound_interest(2000, 3, 3), 2))
    print("Trajectory guard test:")
    print(trajectory_guard([(200, False), (-1500, False), (100, True)], 1500))
    print("Termination-flag test:")
    print(trajectory_guard([(50, True), (500, False)], 2000))

    print("\n[UNIT 2] Manual parser")
    examples = ['Acc101,SAVINGS,5200.00', 'Acc102,"CURRENT, SPECIAL",800.00,', 'Acc103,"say ""hello""",250.00']
    for example in examples:
        print(example, "=>", parse_raw_log_line(example))
    audit = create_audit_filter(1000)
    print("Audit results:", audit(["Acc101", "SAVINGS", "5200"]), audit(["Acc102", "CURRENT", "500"]))
    print("Audit count:", audit.get_count())
    positional = build_positional_filters(["Acc101", "SAVINGS"])
    sample_row = ["Acc101", "SAVINGS", "5200"]
    print("Lambda filter results:", [check(sample_row) for check in positional])

    print("\n[UNIT 3] Reverse index and in-place queue")
    raw_db = {
        "BRANCH_01": [("Acc101", {"DEPOSIT", "UPI"}), ("Acc102", {"LOAN", "UPI"})],
        "BRANCH_02": [("Acc101", {"SAVINGS", "UPI"}), ("Acc103", {"CARD", "DEPOSIT"})]
    }
    print("Reverse index:", build_reverse_index(raw_db))
    queue = [(3, 1), [2, 9, 4], {1, 2, 3, 4, 5}, 7, 7, "TX", "TX"]
    original_id = id(queue)
    print("Queue before:", queue)
    clean_transaction_queue(queue)
    print("Queue after:", queue, "| same id:", original_id == id(queue))

    print("\n[UNIT 4] File update and exception hierarchy")
    print("Exception inheritance:", issubclass(CorruptedRecordError, BaseSystemError),
          issubclass(OutOfBoundsError, BaseSystemError),
          issubclass(InsufficientBalanceError, BaseSystemError))
    update_account_record("Acc101", 5300.0)

    print("\n[UNIT 5] Encapsulation and polymorphic settlement")
    savings = SavingsAccount("Acc201", 1400)
    current = CurrentAccount("Acc202", 1200, 2000)
    credit = CreditAccount("Acc203", 1000, 5000)
    print("Private balance through getter:", savings.get_balance())
    print("Correct mangled attribute access:", savings._Account__balance)
    try:
        print(savings.__balance)
    except AttributeError as error:
        print("Expected name-mangling error:", error)
    print("Total accounts created:", Account.total_accounts)
    execute_batch_settlement([savings, current, credit], 500)

    print("\nDemo finished. Files used: accounts.db, ledger.txt, corrupted.log")
    print("Enter CLI mode? Type YES to start, or press Enter to finish.")
    choice = input("Start CLI [YES/no]: ").strip().upper()
    if choice == "YES":
        run_banking_cli()


if __name__ == "__main__":
    run_demonstrations()
