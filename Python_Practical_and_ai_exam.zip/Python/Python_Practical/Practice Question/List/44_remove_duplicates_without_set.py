# Program 44: Accept a list of integers from the user.
# Remove all duplicate elements without using a set and display the unique list.

raw_input = input("Enter integers separated by spaces (press Enter for default): ").strip()
if raw_input:
    numbers = [int(x) for x in raw_input.split()]
else:
    numbers = [10, 20, 30, 20, 10, 40, 50, 30, 60]
    print(f"Using default list: {numbers}")

unique_list = []
for num in numbers:
    if num not in unique_list:
        unique_list.append(num)

print(f"Original list:                    {numbers}")
print(f"Unique list (without using set): {unique_list}")
