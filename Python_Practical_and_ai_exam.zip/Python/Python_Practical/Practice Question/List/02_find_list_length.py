# Program 02: Find the length of a list.

sample_list = [15, 30, 45, 60, 75, 90, 105]

# Method 1: Using built-in len() function
length_builtin = len(sample_list)

# Method 2: Without using len() (manual count loop)
count = 0
for _ in sample_list:
    count += 1

print(f"List: {sample_list}")
print(f"Length using len(): {length_builtin}")
print(f"Length using manual count loop: {count}")
