# Program 08: Check if an element exists in a list.

fruits = ["apple", "banana", "mango", "orange", "grapes"]
search_item = "mango"

# Method 1: 'in' operator
exists_in = search_item in fruits

# Method 2: Linear search
found = False
found_index = -1
for i, item in enumerate(fruits):
    if item == search_item:
        found = True
        found_index = i
        break

print(f"List: {fruits}")
print(f"Searching for: '{search_item}'")
print(f"Found using 'in' operator? {exists_in}")
if found:
    print(f"Found via linear search at index: {found_index}")
else:
    print("Element does not exist in the list.")
