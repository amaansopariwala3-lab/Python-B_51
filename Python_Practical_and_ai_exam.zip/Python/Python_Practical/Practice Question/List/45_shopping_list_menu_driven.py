# Program 45: Create a shopping list.
# Implement a menu-driven program to add, remove, search, update, sort, and display items.

shopping_list = ["Milk", "Eggs", "Bread", "Butter"]

def show_menu():
    print("\n=== Shopping List Menu ===")
    print("1. Add Item")
    print("2. Remove Item")
    print("3. Search Item")
    print("4. Update Item")
    print("5. Sort Items")
    print("6. Display Items")
    print("7. Exit")

while True:
    show_menu()
    choice = input("Enter choice (1-7): ").strip()

    if choice == "1":
        item = input("Enter item to add: ").strip()
        shopping_list.append(item)
        print(f"'{item}' added to the list.")

    elif choice == "2":
        item = input("Enter item to remove: ").strip()
        if item in shopping_list:
            shopping_list.remove(item)
            print(f"'{item}' removed from the list.")
        else:
            print("Item not found in the list.")

    elif choice == "3":
        item = input("Enter item to search: ").strip()
        if item in shopping_list:
            print(f"'{item}' found at index {shopping_list.index(item)}.")
        else:
            print("Item not found.")

    elif choice == "4":
        old_item = input("Enter item name to update: ").strip()
        if old_item in shopping_list:
            new_item = input("Enter replacement item name: ").strip()
            idx = shopping_list.index(old_item)
            shopping_list[idx] = new_item
            print(f"Updated '{old_item}' to '{new_item}'.")
        else:
            print("Item not found.")

    elif choice == "5":
        shopping_list.sort()
        print("Shopping list sorted alphabetically.")

    elif choice == "6":
        print(f"Current shopping list: {shopping_list}")

    elif choice == "7":
        print("Exiting Shopping List program.")
        break

    else:
        print("Invalid choice, please enter 1 to 7.")
