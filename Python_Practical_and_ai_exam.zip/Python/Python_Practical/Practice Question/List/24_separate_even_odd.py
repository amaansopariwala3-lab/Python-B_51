# Program 24: Separate even and odd numbers into two lists.

numbers = [12, 17, 24, 33, 40, 55, 68, 79, 82, 91]

evens = [x for x in numbers if x % 2 == 0]
odds = [x for x in numbers if x % 2 != 0]

print(f"Original list: {numbers}")
print(f"Even numbers:  {evens}")
print(f"Odd numbers:   {odds}")
