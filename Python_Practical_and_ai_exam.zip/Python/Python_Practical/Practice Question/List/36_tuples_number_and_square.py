# Program 36: Create a list of tuples (number, square) for 1–10.

tuples_list = [(x, x ** 2) for x in range(1, 11)]

print("List of (number, square) tuples for 1 to 10:")
for item in tuples_list:
    print(item)
