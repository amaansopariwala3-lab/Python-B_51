# Program 29: Remove None or empty values from a list.

data = ["Hello", "", None, "World", [], 42, None, {}, "Python"]

# Filter out None and empty collections/strings
cleaned = [x for x in data if x is not None and x != "" and x != [] and x != {}]

print(f"Original list: {data}")
print(f"Cleaned list:  {cleaned}")
