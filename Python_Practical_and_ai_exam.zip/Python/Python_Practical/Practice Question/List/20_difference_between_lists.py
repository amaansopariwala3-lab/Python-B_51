# Program 20: Find elements present in one list but not another.

list1 = [1, 2, 3, 4, 5, 6]
list2 = [4, 5, 6, 7, 8]

in_1_not_2 = [x for x in list1 if x not in list2]
in_2_not_1 = [x for x in list2 if x not in list1]

print(f"List 1: {list1}")
print(f"List 2: {list2}")
print(f"Elements in List 1 but not in List 2: {in_1_not_2}")
print(f"Elements in List 2 but not in List 1: {in_2_not_1}")
