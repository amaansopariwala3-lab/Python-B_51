# Program 31: Find the intersection, union, and difference of two lists.

list_a = [1, 2, 3, 4, 5]
list_b = [4, 5, 6, 7, 8]

set_a = set(list_a)
set_b = set(list_b)

intersection = sorted(list(set_a & set_b))
union = sorted(list(set_a | set_b))
diff_a_b = sorted(list(set_a - set_b))
diff_b_a = sorted(list(set_b - set_a))

print(f"List A:             {list_a}")
print(f"List B:             {list_b}")
print(f"Intersection:       {intersection}")
print(f"Union:              {union}")
print(f"Difference (A - B): {diff_a_b}")
print(f"Difference (B - A): {diff_b_a}")
