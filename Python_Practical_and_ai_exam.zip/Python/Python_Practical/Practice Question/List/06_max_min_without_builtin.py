# Program 06: Find maximum and minimum without using max()/min().

numbers = [45, 12, 89, 3, 76, 99, 21, 64]

if not numbers:
    print("List is empty!")
else:
    maximum = numbers[0]
    minimum = numbers[0]

    for num in numbers[1:]:
        if num > maximum:
            maximum = num
        if num < minimum:
            minimum = num

    print(f"List: {numbers}")
    print(f"Maximum element: {maximum}")
    print(f"Minimum element: {minimum}")
