# Program 33: Group elements by a condition (odd/even, length of strings).

# Condition 1: Grouping numbers by Odd / Even
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
parity_group = {
    "Even": [x for x in numbers if x % 2 == 0],
    "Odd": [x for x in numbers if x % 2 != 0]
}

# Condition 2: Grouping strings by length
words = ["cat", "apple", "banana", "dog", "elephant", "kiwi", "pear"]
length_group = {}
for word in words:
    length_group.setdefault(len(word), []).append(word)

print(f"Numbers: {numbers}")
print(f"Grouped by Parity: {parity_group}")
print(f"\nWords: {words}")
print(f"Grouped by Length: {dict(sorted(length_group.items()))}")
