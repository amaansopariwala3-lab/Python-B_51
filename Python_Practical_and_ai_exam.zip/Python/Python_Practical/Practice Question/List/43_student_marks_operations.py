# Program 43: Create a list of 10 student marks. Perform insertion, deletion, updating,
# sorting, reversing, and display highest, lowest, and average marks.

marks = [78, 85, 92, 65, 88, 73, 90, 82, 59, 95]
print(f"Initial marks list: {marks}")

# 1. Insertion
marks.insert(3, 80)
print(f"After inserting 80 at index 3: {marks}")

# 2. Deletion
deleted_item = marks.pop(5)
print(f"After deleting element at index 5 ({deleted_item}): {marks}")

# 3. Updating
marks[0] = 84
print(f"After updating index 0 to 84: {marks}")

# 4. Sorting
marks.sort()
print(f"After sorting in ascending order: {marks}")

# 5. Reversing
marks.reverse()
print(f"After reversing (descending order): {marks}")

# 6. Statistics
highest = max(marks)
lowest = min(marks)
average = sum(marks) / len(marks)

print(f"Highest Marks: {highest}")
print(f"Lowest Marks:  {lowest}")
print(f"Average Marks: {average:.2f}")
