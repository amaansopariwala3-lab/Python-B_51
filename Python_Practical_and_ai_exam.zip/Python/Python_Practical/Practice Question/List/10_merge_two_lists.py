# Program 10: Merge two lists into one.

list1 = [1, 2, 3]
list2 = [4, 5, 6]

# Method 1: Using + operator
merged_plus = list1 + list2

# Method 2: Using extend()
extended_list = list1.copy()
extended_list.extend(list2)

# Method 3: Unpacking operator *
merged_unpack = [*list1, *list2]

print(f"List 1: {list1}")
print(f"List 2: {list2}")
print(f"Merged with +:          {merged_plus}")
print(f"Merged with extend():   {extended_list}")
print(f"Merged with unpacking:  {merged_unpack}")
