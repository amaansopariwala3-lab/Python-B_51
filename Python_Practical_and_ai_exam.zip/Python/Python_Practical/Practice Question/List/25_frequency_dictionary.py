# Program 25: Find the frequency of each element (build a dictionary).

items = ["apple", "banana", "apple", "cherry", "banana", "apple", "date"]

freq = {}
for item in items:
    freq[item] = freq.get(item, 0) + 1

print(f"List: {items}")
print("Frequency Dictionary:")
for key, value in freq.items():
    print(f"  '{key}': {value}")
