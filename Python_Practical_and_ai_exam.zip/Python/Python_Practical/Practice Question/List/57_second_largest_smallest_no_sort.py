# Program 57: Find the second largest and second smallest element in a list
# without using built-in sorting.

numbers = [14, 28, 5, 92, 45, 92, 3, 58, 3]

# Extract unique elements to avoid duplicate extremes
unique = []
for x in numbers:
    if x not in unique:
        unique.append(x)

if len(unique) < 2:
    print("List must have at least 2 distinct elements.")
else:
    largest = second_largest = float('-inf')
    smallest = second_smallest = float('inf')

    for num in unique:
        # Check largest & second largest
        if num > largest:
            second_largest = largest
            largest = num
        elif num > second_largest:
            second_largest = num

        # Check smallest & second smallest
        if num < smallest:
            second_smallest = smallest
            smallest = num
        elif num < second_smallest:
            second_smallest = num

    print(f"Original list:   {numbers}")
    print(f"Unique elements: {unique}")
    print(f"Smallest:        {smallest}")
    print(f"Second Smallest: {second_smallest}")
    print(f"Largest:         {largest}")
    print(f"Second Largest:  {second_largest}")
