# Program 66: Accept a list of marks and assign grades (A, B, C, D, F)
# using list comprehension.

user_in = input("Enter marks separated by spaces (press Enter for default): ").strip()
marks = [float(x) for x in user_in.split()] if user_in else [95, 82, 74, 63, 45, 32, 88]

# Grading rule:
# >= 90: A
# >= 80: B
# >= 70: C
# >= 50: D
# < 50:  F
grades = [
    'A' if m >= 90 else
    'B' if m >= 80 else
    'C' if m >= 70 else
    'D' if m >= 50 else 'F'
    for m in marks
]

print(f"\n{'Marks':<10} | {'Grade':<6}")
print("-" * 18)
for m, g in zip(marks, grades):
    print(f"{m:<10.1f} | {g:<6}")
