# Program 22: Remove all occurrences of a specific value.

numbers = [1, 3, 7, 3, 9, 3, 3, 11]
target = 3

# Method 1: List comprehension
filtered = [x for x in numbers if x != target]

# Method 2: While loop with remove()
numbers_copy = numbers.copy()
while target in numbers_copy:
    numbers_copy.remove(target)

print(f"Original list:          {numbers}")
print(f"Value to remove:        {target}")
print(f"Result (comprehension): {filtered}")
print(f"Result (while loop):    {numbers_copy}")
