# Program 42: Filter numbers divisible by both 3 and 5.

numbers = list(range(1, 101))
divisible_both = [x for x in numbers if x % 3 == 0 and x % 5 == 0]

print("Numbers 1 to 100 divisible by both 3 and 5:")
print(divisible_both)
