# Program 13: Remove duplicates from a list.

numbers = [1, 2, 2, 3, 4, 4, 4, 5, 1, 6]

# Method 1: Preserving original order
unique_ordered = []
for item in numbers:
    if item not in unique_ordered:
        unique_ordered.append(item)

# Method 2: Using set
unique_set = list(set(numbers))

print(f"Original list:                     {numbers}")
print(f"Duplicates removed (order kept):   {unique_ordered}")
print(f"Duplicates removed (using set):    {unique_set}")
