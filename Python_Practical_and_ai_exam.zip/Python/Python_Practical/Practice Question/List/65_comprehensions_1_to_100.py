# Program 65: Create a list using list comprehension for numbers from 1 to 100 and display:
# Squares, Cubes, Even numbers, Odd numbers, Multiples of 5.

squares = [x ** 2 for x in range(1, 101)]
cubes = [x ** 3 for x in range(1, 101)]
evens = [x for x in range(1, 101) if x % 2 == 0]
odds = [x for x in range(1, 101) if x % 2 != 0]
multiples_5 = [x for x in range(1, 101) if x % 5 == 0]

print("1. Squares 1-100 (first 10):", squares[:10], "...")
print("2. Cubes 1-100 (first 10):  ", cubes[:10], "...")
print("3. Even numbers (first 10): ", evens[:10], "...")
print("4. Odd numbers (first 10):  ", odds[:10], "...")
print("5. Multiples of 5:          ", multiples_5)
