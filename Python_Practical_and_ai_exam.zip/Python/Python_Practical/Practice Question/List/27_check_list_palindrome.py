# Program 27: Check if a list is a palindrome.

list1 = [1, 2, 3, 2, 1]
list2 = [1, 2, 3, 4, 5]

def is_palindrome(lst):
    return lst == lst[::-1]

print(f"List 1: {list1} -> Is Palindrome? {is_palindrome(list1)}")
print(f"List 2: {list2} -> Is Palindrome? {is_palindrome(list2)}")
