# Program 59: Accept a list of numbers and separate them into positive,
# negative, and zero lists.

user_in = input("Enter numbers separated by spaces (press Enter for default): ").strip()
numbers = [int(x) for x in user_in.split()] if user_in else [10, -5, 0, 23, -42, 0, 7, -1, 0, 19]

positives = [x for x in numbers if x > 0]
negatives = [x for x in numbers if x < 0]
zeros = [x for x in numbers if x == 0]

print(f"\nOriginal list: {numbers}")
print(f"Positive numbers ({len(positives)}): {positives}")
print(f"Negative numbers ({len(negatives)}): {negatives}")
print(f"Zero values ({len(zeros)}):          {zeros}")
