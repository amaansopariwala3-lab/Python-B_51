# Program 04: Reverse a list without using reverse().

original = [1, 2, 3, 4, 5, 6, 7, 8]

# Method 1: Slicing
reversed_slice = original[::-1]

# Method 2: Using backward loop
reversed_loop = []
for i in range(len(original) - 1, -1, -1):
    reversed_loop.append(original[i])

# Method 3: In-place two-pointer swap
in_place = original.copy()
left, right = 0, len(in_place) - 1
while left < right:
    in_place[left], in_place[right] = in_place[right], in_place[left]
    left += 1
    right -= 1

print(f"Original list: {original}")
print(f"Reversed using slicing [::-1]: {reversed_slice}")
print(f"Reversed using backward loop:  {reversed_loop}")
print(f"Reversed using two pointers:   {in_place}")
