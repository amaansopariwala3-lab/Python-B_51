# Program 12: Copy a list (shallow copy) and show it doesn't affect original.

original = [10, 20, 30, 40]

# Creating shallow copies
copy1 = original.copy()
copy2 = list(original)
copy3 = original[:]

# Modifying the copy
copy1.append(50)
copy1[0] = 999

print(f"Original list:       {original}")
print(f"Modified copy1:      {copy1}")
print("Result: Modifying the copy did not affect the original list.")
