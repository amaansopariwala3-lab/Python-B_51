# Program 41: Create a multiplication table (list of lists) using comprehension.

table = [[i * j for j in range(1, 11)] for i in range(1, 11)]

print("Multiplication Table (1 to 10):")
for idx, row in enumerate(table, start=1):
    print(f"Table of {idx:2d}: {row}")
