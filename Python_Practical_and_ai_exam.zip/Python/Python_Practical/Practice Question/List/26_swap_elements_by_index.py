# Program 26: Swap two elements at given positions.

numbers = [10, 20, 30, 40, 50]
pos1, pos2 = 1, 3  # Swapping elements at index 1 and index 3

print(f"Initial list:                           {numbers}")
print(f"Swapping index {pos1} ({numbers[pos1]}) with index {pos2} ({numbers[pos2]})...")

numbers[pos1], numbers[pos2] = numbers[pos2], numbers[pos1]

print(f"List after swapping:                    {numbers}")
