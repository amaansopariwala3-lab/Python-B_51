# Program 58: Create a list of numbers and replace every negative number with zero.

numbers = [12, -7, 45, -3, 0, -18, 55, -90, 24]

# Replace negatives with zero
modified = [0 if x < 0 else x for x in numbers]

print(f"Original numbers: {numbers}")
print(f"Negatives zeroed: {modified}")
