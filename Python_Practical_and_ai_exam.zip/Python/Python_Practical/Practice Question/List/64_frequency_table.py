# Program 64: Create a frequency table of elements in a list.

data = ["Apple", "Orange", "Banana", "Apple", "Mango", "Banana", "Apple", "Grapes", "Orange"]

freq = {}
for item in data:
    freq[item] = freq.get(item, 0) + 1

total_count = len(data)

print(f"Dataset: {data}\n")
print(f"{'Element':<15} | {'Frequency':<10} | {'Percentage':<10}")
print("-" * 42)
for item, count in sorted(freq.items()):
    percentage = (count / total_count) * 100
    print(f"{item:<15} | {count:<10} | {percentage:>6.2f}%")
print("-" * 42)
print(f"{'Total':<15} | {total_count:<10} | 100.00%")
