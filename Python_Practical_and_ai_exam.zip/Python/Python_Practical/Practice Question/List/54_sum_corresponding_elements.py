# Program 54: Accept two lists of equal size and create a third list containing
# the sum of corresponding elements.

list1 = [10, 20, 30, 40, 50]
list2 = [1, 2, 3, 4, 5]

sum_list = [a + b for a, b in zip(list1, list2)]

print(f"List 1: {list1}")
print(f"List 2: {list2}")
print(f"Sum of corresponding elements: {sum_list}")
