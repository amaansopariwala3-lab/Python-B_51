# Program 07: Count how many times a value appears in a list.

data = [10, 20, 30, 20, 40, 20, 50, 20, 60]
target = 20

# Manual counting loop
count = 0
for item in data:
    if item == target:
        count += 1

# Built-in count method
builtin_count = data.count(target)

print(f"List: {data}")
print(f"Target value: {target}")
print(f"Occurrences (manual loop): {count}")
print(f"Occurrences (.count()):     {builtin_count}")
