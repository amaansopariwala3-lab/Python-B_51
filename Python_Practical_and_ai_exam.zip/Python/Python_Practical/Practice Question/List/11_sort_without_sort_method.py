# Program 11: Sort a list in ascending and descending order (without sort()).

numbers = [64, 25, 12, 22, 11, 90, 45]

def bubble_sort(lst, ascending=True):
    arr = lst.copy()
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if ascending:
                if arr[j] > arr[j + 1]:
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
            else:
                if arr[j] < arr[j + 1]:
                    arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr

asc = bubble_sort(numbers, ascending=True)
desc = bubble_sort(numbers, ascending=False)

print(f"Original list:    {numbers}")
print(f"Ascending order:  {asc}")
print(f"Descending order: {desc}")
