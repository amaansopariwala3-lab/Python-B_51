# Program 18: Flatten a nested list (e.g., [[1,2],[3,4]] -> [1,2,3,4]).

nested = [[1, 2], [3, 4], [5, 6, 7], [8]]

# Method 1: Loops
flat_loop = []
for sub in nested:
    for item in sub:
        flat_loop.append(item)

# Method 2: List comprehension
flat_comp = [item for sub in nested for item in sub]

print(f"Nested list:                    {nested}")
print(f"Flattened list (loop):          {flat_loop}")
print(f"Flattened list (comprehension): {flat_comp}")
