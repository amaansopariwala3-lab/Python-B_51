# Program 62: Create a matrix using nested lists and perform:
# Matrix addition, Matrix transpose, Sum of each row, Sum of each column.

matrix_a = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

matrix_b = [
    [9, 8, 7],
    [6, 5, 4],
    [3, 2, 1]
]

rows = len(matrix_a)
cols = len(matrix_a[0])

# 1. Matrix Addition
matrix_sum = [[matrix_a[i][j] + matrix_b[i][j] for j in range(cols)] for i in range(rows)]

# 2. Matrix Transpose
transpose_a = [[matrix_a[j][i] for j in range(rows)] for i in range(cols)]

# 3. Sum of each row
row_sums = [sum(row) for row in matrix_a]

# 4. Sum of each column
col_sums = [sum(matrix_a[i][j] for i in range(rows)) for j in range(cols)]

print("Matrix A:")
for r in matrix_a:
    print(" ", r)

print("\nMatrix B:")
for r in matrix_b:
    print(" ", r)

print("\n1. Matrix Addition (A + B):")
for r in matrix_sum:
    print(" ", r)

print("\n2. Matrix Transpose of A:")
for r in transpose_a:
    print(" ", r)

print(f"\n3. Sum of each row (Matrix A):    {row_sums}")
print(f"4. Sum of each column (Matrix A): {col_sums}")
