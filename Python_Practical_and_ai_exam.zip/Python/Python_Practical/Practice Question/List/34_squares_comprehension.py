# Program 34: Create a list of squares of numbers 1–20 using a comprehension.

squares = [x ** 2 for x in range(1, 21)]

print("Squares of numbers 1 to 20:")
print(squares)
