# Program 21: Rotate a list left/right by n positions.

lst = [10, 20, 30, 40, 50, 60, 70]
n = 2

# Calculate effective rotation steps
k = n % len(lst) if lst else 0

# Left rotation: elements shift left, front wraps to end
rotate_left = lst[k:] + lst[:k]

# Right rotation: elements shift right, end wraps to front
rotate_right = lst[-k:] + lst[:-k]

print(f"Original list:       {lst}")
print(f"Rotated left by {n}:  {rotate_left}")
print(f"Rotated right by {n}: {rotate_right}")
