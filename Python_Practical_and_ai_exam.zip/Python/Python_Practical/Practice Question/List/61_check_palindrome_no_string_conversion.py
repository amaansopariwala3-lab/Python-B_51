# Program 61: Accept a list and check whether it is a palindrome
# without converting it into a string.

sample_list = [10, 20, 30, 20, 10]

def is_palindrome_list(lst):
    left = 0
    right = len(lst) - 1
    while left < right:
        if lst[left] != lst[right]:
            return False
        left += 1
        right -= 1
    return True

print(f"List: {sample_list}")
if is_palindrome_list(sample_list):
    print("The list IS a Palindrome (checked via index pointers).")
else:
    print("The list is NOT a Palindrome.")
