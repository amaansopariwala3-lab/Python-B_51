# Program 15: Find the average of numbers in a list.

scores = [85, 90, 78, 92, 88, 76, 95]

total = sum(scores)
count = len(scores)

if count > 0:
    average = total / count
    print(f"Numbers: {scores}")
    print(f"Sum:     {total}")
    print(f"Count:   {count}")
    print(f"Average: {average:.2f}")
else:
    print("List is empty.")
