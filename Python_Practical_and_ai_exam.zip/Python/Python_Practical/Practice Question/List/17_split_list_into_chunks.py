# Program 17: Split a list into chunks of size n.

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
chunk_size = 3

chunks = [numbers[i:i + chunk_size] for i in range(0, len(numbers), chunk_size)]

print(f"Original list: {numbers}")
print(f"Chunk size:    {chunk_size}")
print(f"Chunks:        {chunks}")
