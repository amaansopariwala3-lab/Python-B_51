# Program 23: Find all pairs in a list that sum to a target value.

numbers = [2, 4, 3, 5, 7, 8, 9, 1]
target_sum = 10

pairs = []
seen = set()

for i in range(len(numbers)):
    for j in range(i + 1, len(numbers)):
        if numbers[i] + numbers[j] == target_sum:
            pair = tuple(sorted((numbers[i], numbers[j])))
            if pair not in seen:
                seen.add(pair)
                pairs.append(pair)

print(f"Numbers:             {numbers}")
print(f"Target sum:          {target_sum}")
print(f"Unique pairs found:  {pairs}")
