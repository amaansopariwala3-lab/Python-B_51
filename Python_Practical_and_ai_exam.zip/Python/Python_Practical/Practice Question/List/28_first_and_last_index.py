# Program 28: Find the index of the first/last occurrence of an element.

numbers = [10, 20, 30, 20, 40, 20, 50]
target = 20

first_index = -1
last_index = -1

for index, val in enumerate(numbers):
    if val == target:
        if first_index == -1:
            first_index = index
        last_index = index

print(f"List:   {numbers}")
print(f"Target: {target}")
if first_index != -1:
    print(f"First occurrence index: {first_index}")
    print(f"Last occurrence index:  {last_index}")
else:
    print("Target not found.")
