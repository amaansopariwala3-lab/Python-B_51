# Program 39: Convert a list of strings to uppercase using comprehension.

words = ["python", "programming", "list", "comprehension", "tutorial"]
uppercase_words = [w.upper() for w in words]

print(f"Original words:  {words}")
print(f"Uppercase words: {uppercase_words}")
