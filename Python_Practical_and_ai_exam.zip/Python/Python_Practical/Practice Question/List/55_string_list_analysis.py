# Program 55: Create a list of strings. Display:
# Longest string, Shortest string, Strings starting with a vowel, Strings ending with a consonant.

words = ["umbrella", "sky", "elephant", "orange", "cloud", "ice", "fly"]

longest = max(words, key=len)
shortest = min(words, key=len)

vowels = ('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U')

start_vowel = [w for w in words if w.startswith(vowels)]
end_consonant = [w for w in words if w and w[-1].isalpha() and w[-1] not in vowels]

print(f"List of strings:                 {words}")
print(f"Longest string:                  '{longest}' (length: {len(longest)})")
print(f"Shortest string:                 '{shortest}' (length: {len(shortest)})")
print(f"Strings starting with a vowel:   {start_vowel}")
print(f"Strings ending with a consonant: {end_consonant}")
