# Program 52: Accept a list of numbers and perform slicing operations to display:
# First five elements, Last five elements, Alternate elements, Reverse list using slicing.

user_input = input("Enter numbers separated by spaces (press Enter for default): ").strip()
if user_input:
    numbers = [int(x) for x in user_input.split()]
else:
    numbers = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    print(f"Using default list: {numbers}")

print(f"\nOriginal List:       {numbers}")
print(f"First five elements: {numbers[:5]}")
print(f"Last five elements:  {numbers[-5:]}")
print(f"Alternate elements:  {numbers[::2]}")
print(f"Reversed list:       {numbers[::-1]}")
