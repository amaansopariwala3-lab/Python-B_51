# Program 46: Merge two lists, remove duplicate elements, sort the final list,
# and display it in ascending and descending order.

list1 = [5, 12, 9, 21, 3]
list2 = [9, 14, 5, 30, 21, 1]

# 1. Merge
merged = list1 + list2

# 2. Remove duplicates
unique_list = []
for item in merged:
    if item not in unique_list:
        unique_list.append(item)

# 3. Sort ascending and descending
ascending = sorted(unique_list)
descending = sorted(unique_list, reverse=True)

print(f"List 1:                   {list1}")
print(f"List 2:                   {list2}")
print(f"Merged without duplicates: {unique_list}")
print(f"Ascending Order:          {ascending}")
print(f"Descending Order:         {descending}")
