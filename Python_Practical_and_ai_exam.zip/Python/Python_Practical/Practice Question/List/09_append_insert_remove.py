# Program 09: Append, insert, and remove elements.

items = ["Python", "Java", "C++"]
print(f"Initial list: {items}")

# 1. Append adds element at the end
items.append("JavaScript")
print(f"After append('JavaScript'): {items}")

# 2. Insert adds element at a specific index
items.insert(1, "Go")
print(f"After insert(1, 'Go'):       {items}")

# 3. Remove deletes first occurrence of the specified value
items.remove("Java")
print(f"After remove('Java'):        {items}")
