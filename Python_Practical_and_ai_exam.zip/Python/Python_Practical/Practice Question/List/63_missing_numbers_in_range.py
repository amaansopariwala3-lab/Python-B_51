# Program 63: Accept a list of integers and find all missing numbers
# between the minimum and maximum value.

user_in = input("Enter integers separated by spaces (press Enter for default): ").strip()
numbers = [int(x) for x in user_in.split()] if user_in else [10, 11, 14, 15, 18, 20]

min_val = min(numbers)
max_val = max(numbers)
num_set = set(numbers)

missing_numbers = [x for x in range(min_val, max_val + 1) if x not in num_set]

print(f"Given numbers: {sorted(numbers)}")
print(f"Range: from {min_val} to {max_val}")
print(f"Missing numbers in this range: {missing_numbers}")
