# Program 03: Access the first, last, and middle elements.

numbers = [10, 20, 30, 40, 50, 60, 70]

first_element = numbers[0]
last_element = numbers[-1]

mid_index = len(numbers) // 2
if len(numbers) % 2 == 1:
    middle_element = numbers[mid_index]
    mid_display = f"Middle element (odd length, index {mid_index}): {middle_element}"
else:
    mid1, mid2 = numbers[mid_index - 1], numbers[mid_index]
    mid_display = f"Middle elements (even length, indices {mid_index - 1}, {mid_index}): {mid1}, {mid2}"

print(f"List: {numbers}")
print(f"First element: {first_element}")
print(f"Last element: {last_element}")
print(mid_display)
