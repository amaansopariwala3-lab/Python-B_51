# Program 56: Accept a list of integers and rotate the list by k positions (left and right).

user_in = input("Enter integers separated by spaces (press Enter for default): ").strip()
numbers = [int(x) for x in user_in.split()] if user_in else [10, 20, 30, 40, 50, 60]

k_in = input("Enter k positions to rotate (press Enter for default 2): ").strip()
k = int(k_in) if k_in else 2

n = len(numbers)
effective_k = k % n if n > 0 else 0

left_rotated = numbers[effective_k:] + numbers[:effective_k]
right_rotated = numbers[-effective_k:] + numbers[:-effective_k]

print(f"Original list:       {numbers}")
print(f"Rotated Left by {k}:  {left_rotated}")
print(f"Rotated Right by {k}: {right_rotated}")
