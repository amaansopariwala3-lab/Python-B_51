# Program 48: Create a list of employee names. Search for a name,
# update it if found, otherwise add it to the list.

employees = ["Alice", "Bob", "Charlie", "David", "Emma"]

print(f"Current Employee List: {employees}")
name = input("Enter employee name to search: ").strip()

if name in employees:
    print(f"Employee '{name}' found at index {employees.index(name)}.")
    new_name = input("Enter new name to update: ").strip()
    idx = employees.index(name)
    employees[idx] = new_name
    print(f"Updated '{name}' to '{new_name}'.")
else:
    print(f"Employee '{name}' not found. Adding to the list.")
    employees.append(name)

print(f"Updated Employee List: {employees}")
