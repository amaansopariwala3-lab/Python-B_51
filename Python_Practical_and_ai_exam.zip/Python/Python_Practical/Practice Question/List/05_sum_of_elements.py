# Program 05: Sum all elements in a list.

numbers = [12, 18, 25, 40, 55]

# Method 1: Using loop
total = 0
for num in numbers:
    total += num

# Method 2: Using sum() function
builtin_total = sum(numbers)

print(f"Numbers: {numbers}")
print(f"Sum calculated using loop:  {total}")
print(f"Sum calculated using sum(): {builtin_total}")
