# Program 19: Find common elements between two lists.

list_a = [10, 20, 30, 40, 50, 60]
list_b = [30, 50, 70, 80, 20]

# Method 1: Loop comprehension
common_loop = [x for x in list_a if x in list_b]

# Method 2: Set intersection
common_set = list(set(list_a) & set(list_b))

print(f"List A: {list_a}")
print(f"List B: {list_b}")
print(f"Common elements (loop): {common_loop}")
print(f"Common elements (set):  {common_set}")
