# Program 01: Create a list of 10 numbers and print it.

# Creating a list of 10 numbers
numbers = [10, 25, 33, 48, 52, 67, 71, 84, 96, 100]

print("List of 10 numbers:")
print(numbers)

print("\nPrinting elements with their indices:")
for index, value in enumerate(numbers):
    print(f"Index {index}: {value}")
