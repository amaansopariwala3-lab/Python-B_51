# Program 67: Develop a menu-driven Student Record Management System using lists
# that supports: Add student, Display all students, Search student, Update student,
# Delete student, Sort by name, Sort by marks, Display topper, Display average marks, Exit.

students = [
    [101, "Aarav", 88.5],
    [102, "Diya", 94.0],
    [103, "Kabir", 76.5]
]

def show_menu():
    print("\n" + "=" * 45)
    print("     STUDENT RECORD MANAGEMENT SYSTEM")
    print("=" * 45)
    print("1.  Add Student")
    print("2.  Display All Students")
    print("3.  Search Student")
    print("4.  Update Student")
    print("5.  Delete Student")
    print("6.  Sort by Name")
    print("7.  Sort by Marks")
    print("8.  Display Topper")
    print("9.  Display Average Marks")
    print("10. Exit")

while True:
    show_menu()
    choice = input("Enter your choice (1-10): ").strip()

    if choice == "1":
        roll = int(input("Enter Roll No: "))
        if any(s[0] == roll for s in students):
            print("Error: Student with this Roll No already exists!")
            continue
        name = input("Enter Student Name: ").strip()
        marks = float(input("Enter Marks: "))
        students.append([roll, name, marks])
        print(f"Student '{name}' added successfully.")

    elif choice == "2":
        if not students:
            print("No records available.")
        else:
            print(f"\n{'Roll No':<10} | {'Name':<15} | {'Marks':<8}")
            print("-" * 38)
            for s in students:
                print(f"{s[0]:<10} | {s[1]:<15} | {s[2]:<8.2f}")

    elif choice == "3":
        query = input("Enter Roll No or Name to search: ").strip()
        found = False
        for s in students:
            if str(s[0]) == query or s[1].lower() == query.lower():
                print(f"Found -> Roll No: {s[0]}, Name: {s[1]}, Marks: {s[2]}")
                found = True
                break
        if not found:
            print("Student not found.")

    elif choice == "4":
        roll = int(input("Enter Roll No of student to update: "))
        found = False
        for s in students:
            if s[0] == roll:
                new_name = input(f"Enter new name (current '{s[1]}'): ").strip()
                new_marks = input(f"Enter new marks (current {s[2]}): ").strip()
                if new_name:
                    s[1] = new_name
                if new_marks:
                    s[2] = float(new_marks)
                print("Record updated successfully.")
                found = True
                break
        if not found:
            print("Student not found.")

    elif choice == "5":
        roll = int(input("Enter Roll No to delete: "))
        idx_to_del = -1
        for i, s in enumerate(students):
            if s[0] == roll:
                idx_to_del = i
                break
        if idx_to_del != -1:
            removed = students.pop(idx_to_del)
            print(f"Deleted student: {removed[1]} (Roll: {removed[0]})")
        else:
            print("Student not found.")

    elif choice == "6":
        students.sort(key=lambda s: s[1].lower())
        print("Students sorted alphabetically by name.")

    elif choice == "7":
        students.sort(key=lambda s: s[2], reverse=True)
        print("Students sorted by marks (highest first).")

    elif choice == "8":
        if not students:
            print("No records available.")
        else:
            topper = max(students, key=lambda s: s[2])
            print(f"Topper: {topper[1]} (Roll No: {topper[0]}) with {topper[2]} marks")

    elif choice == "9":
        if not students:
            print("No records available.")
        else:
            avg_marks = sum(s[2] for s in students) / len(students)
            print(f"Average Marks of {len(students)} students: {avg_marks:.2f}")

    elif choice == "10":
        print("Exiting Student Record Management System.")
        break

    else:
        print("Invalid choice, please enter 1 to 10.")
