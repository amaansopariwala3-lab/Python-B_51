# Program 51: Menu-driven program to perform all list operations:
# Append, Insert, Extend, Remove, Pop, Sort, Reverse, Count, Index, Copy, Clear, Display.

data_list = [10, 20, 30]

menu = """
=== List Operations Menu ===
1. Append      7. Reverse
2. Insert      8. Count
3. Extend      9. Index
4. Remove     10. Copy
5. Pop        11. Clear
6. Sort       12. Display
              13. Exit
"""

while True:
    print(menu)
    choice = input("Enter your choice (1-13): ").strip()

    if choice == "1":
        val = int(input("Enter integer to append: "))
        data_list.append(val)
        print(f"List after append: {data_list}")
    elif choice == "2":
        idx = int(input("Enter index: "))
        val = int(input("Enter value: "))
        data_list.insert(idx, val)
        print(f"List after insert: {data_list}")
    elif choice == "3":
        vals = [int(x) for x in input("Enter space-separated integers to extend: ").split()]
        data_list.extend(vals)
        print(f"List after extend: {data_list}")
    elif choice == "4":
        val = int(input("Enter value to remove: "))
        if val in data_list:
            data_list.remove(val)
            print(f"List after remove: {data_list}")
        else:
            print("Value not found.")
    elif choice == "5":
        if data_list:
            idx_in = input("Enter index to pop (press enter for last): ").strip()
            popped = data_list.pop(int(idx_in)) if idx_in else data_list.pop()
            print(f"Popped value: {popped}. Current list: {data_list}")
        else:
            print("List is empty!")
    elif choice == "6":
        data_list.sort()
        print(f"Sorted list: {data_list}")
    elif choice == "7":
        data_list.reverse()
        print(f"Reversed list: {data_list}")
    elif choice == "8":
        val = int(input("Enter value to count: "))
        print(f"{val} appears {data_list.count(val)} time(s).")
    elif choice == "9":
        val = int(input("Enter value to find index: "))
        if val in data_list:
            print(f"First index of {val}: {data_list.index(val)}")
        else:
            print("Value not found.")
    elif choice == "10":
        copied = data_list.copy()
        print(f"Shallow copy created: {copied}")
    elif choice == "11":
        data_list.clear()
        print("List cleared.")
    elif choice == "12":
        print(f"Current list: {data_list}")
    elif choice == "13":
        print("Exiting.")
        break
    else:
        print("Invalid choice, please enter 1-13.")
