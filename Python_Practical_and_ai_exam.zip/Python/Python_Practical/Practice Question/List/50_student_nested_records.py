# Program 50: Create a nested list containing student details (Roll No., Name, Marks).
# Display topper details and sort students according to marks.

students = [
    [101, "Aarav", 88.5],
    [102, "Diya", 94.0],
    [103, "Kabir", 76.0],
    [104, "Ananya", 96.5],
    [105, "Rohan", 82.0]
]

print("Student Records [Roll No, Name, Marks]:")
for s in students:
    print(f"  Roll No: {s[0]} | Name: {s[1]:10s} | Marks: {s[2]}")

# 1. Display topper details
topper = max(students, key=lambda s: s[2])
print(f"\nTopper: {topper[1]} (Roll: {topper[0]}) with {topper[2]} marks")

# 2. Sort students according to marks (descending)
sorted_students = sorted(students, key=lambda s: s[2], reverse=True)
print("\nStudents Sorted by Marks (Highest to Lowest):")
for s in sorted_students:
    print(f"  Marks: {s[2]:5.1f} | Name: {s[1]:10s} | Roll No: {s[0]}")
