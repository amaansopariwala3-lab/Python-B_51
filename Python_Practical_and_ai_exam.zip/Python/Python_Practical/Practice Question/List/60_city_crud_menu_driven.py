# Program 60: Create a list of cities.
# Perform all CRUD (Create, Read, Update, Delete) operations using a menu-driven approach.

cities = ["Mumbai", "Delhi", "Bengaluru", "Kolkata"]

def show_menu():
    print("\n=== City Manager (CRUD) ===")
    print("1. Create (Add new city)")
    print("2. Read (View all cities)")
    print("3. Update (Rename city)")
    print("4. Delete (Remove city)")
    print("5. Exit")

while True:
    show_menu()
    choice = input("Enter choice (1-5): ").strip()

    if choice == "1":
        city = input("Enter city name to add: ").strip()
        if city:
            cities.append(city)
            print(f"'{city}' added successfully.")
    elif choice == "2":
        print("\nCurrent Cities:")
        for idx, city in enumerate(cities, start=1):
            print(f"  {idx}. {city}")
    elif choice == "3":
        old_city = input("Enter city name to update: ").strip()
        if old_city in cities:
            new_city = input("Enter new city name: ").strip()
            idx = cities.index(old_city)
            cities[idx] = new_city
            print(f"Updated '{old_city}' to '{new_city}'.")
        else:
            print("City not found.")
    elif choice == "4":
        city = input("Enter city name to delete: ").strip()
        if city in cities:
            cities.remove(city)
            print(f"'{city}' deleted successfully.")
        else:
            print("City not found.")
    elif choice == "5":
        print("Exiting City Manager.")
        break
    else:
        print("Invalid choice, please select 1 to 5.")
