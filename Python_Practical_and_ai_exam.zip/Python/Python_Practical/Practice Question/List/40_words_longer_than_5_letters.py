# Program 40: Extract words longer than 5 letters from a sentence.

sentence = "Python provides elegant syntax for data manipulation and list comprehensions."
words = sentence.replace(".", "").replace(",", "").split()

long_words = [w for w in words if len(w) > 5]

print(f'Sentence: "{sentence}"')
print(f"Words longer than 5 letters: {long_words}")
