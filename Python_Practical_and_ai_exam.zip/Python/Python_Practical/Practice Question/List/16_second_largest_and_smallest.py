# Program 16: Find the second largest/smallest number in a list.

numbers = [45, 12, 89, 12, 3, 76, 99, 99, 21, 64]

unique_sorted = sorted(list(set(numbers)))

if len(unique_sorted) < 2:
    print("List needs at least two distinct elements.")
else:
    second_smallest = unique_sorted[1]
    second_largest = unique_sorted[-2]

    print(f"Original list:   {numbers}")
    print(f"Distinct sorted: {unique_sorted}")
    print(f"Second smallest: {second_smallest}")
    print(f"Second largest:  {second_largest}")
