# Program 53: Create a list of 20 numbers and remove all prime numbers from the list.

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

numbers = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]

non_primes = [x for x in numbers if not is_prime(x)]
primes_found = [x for x in numbers if is_prime(x)]

print(f"Original 20 numbers: {numbers}")
print(f"Prime numbers:       {primes_found}")
print(f"After removing primes: {non_primes}")
