# Program 32: Find the longest consecutive sequence of numbers.

numbers = [100, 4, 200, 1, 3, 2, 5, 8, 9]

num_set = set(numbers)
longest_sequence = []

for num in num_set:
    # If num - 1 is not present, num is the start of a sequence
    if num - 1 not in num_set:
        curr = num
        curr_seq = []
        while curr in num_set:
            curr_seq.append(curr)
            curr += 1
        if len(curr_seq) > len(longest_sequence):
            longest_sequence = curr_seq

print(f"Original list:                {numbers}")
print(f"Longest consecutive sequence: {longest_sequence}")
print(f"Sequence length:              {len(longest_sequence)}")
