# Program 49: Accept a sentence from the user, convert it into a list of words,
# count the occurrence of each word, and remove repeated words.

sentence = input("Enter a sentence (press Enter for default): ").strip()
if not sentence:
    sentence = "python is fun and learning python is rewarding and fun"
    print(f"Using default sentence: '{sentence}'")

words = sentence.split()
print(f"\nList of words: {words}")

# Word occurrence counting
word_freq = {}
for w in words:
    word_freq[w] = word_freq.get(w, 0) + 1

print("\nWord Occurrences:")
for word, count in word_freq.items():
    print(f"  '{word}': {count}")

# Remove repeated words preserving order
unique_words = []
for w in words:
    if w not in unique_words:
        unique_words.append(w)

print(f"\nWords with repeats removed: {unique_words}")
