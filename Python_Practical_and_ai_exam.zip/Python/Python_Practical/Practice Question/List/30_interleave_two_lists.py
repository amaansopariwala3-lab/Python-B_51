# Program 30: Interleave two lists (e.g., [1,3,5] and [2,4,6] -> [1,2,3,4,5,6]).

list1 = [1, 3, 5, 7, 9]
list2 = [2, 4, 6]

interleaved = []
max_len = max(len(list1), len(list2))

for i in range(max_len):
    if i < len(list1):
        interleaved.append(list1[i])
    if i < len(list2):
        interleaved.append(list2[i])

print(f"List 1:      {list1}")
print(f"List 2:      {list2}")
print(f"Interleaved: {interleaved}")
