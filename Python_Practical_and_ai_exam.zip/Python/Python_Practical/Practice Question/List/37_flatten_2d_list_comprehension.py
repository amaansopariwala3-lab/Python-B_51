# Program 37: Flatten a 2D list using a nested comprehension.

matrix = [
    [10, 20, 30],
    [40, 50, 60],
    [70, 80, 90]
]

flattened = [val for row in matrix for val in row]

print("2D Matrix:")
for row in matrix:
    print(row)

print(f"\nFlattened List: {flattened}")
