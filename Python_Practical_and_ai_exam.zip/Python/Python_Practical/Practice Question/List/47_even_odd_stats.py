# Program 47: Accept 15 numbers in a list. Separate them into even and odd lists
# and display their count, sum, maximum, and minimum values.

user_input = input("Enter 15 numbers separated by spaces (press Enter for default): ").strip()
if user_input:
    numbers = [int(x) for x in user_input.split()]
else:
    numbers = [12, 7, 19, 24, 33, 46, 51, 60, 77, 82, 95, 14, 28, 37, 50]
    print(f"Using default 15 numbers: {numbers}")

even_list = [x for x in numbers if x % 2 == 0]
odd_list = [x for x in numbers if x % 2 != 0]

print(f"\nAll Numbers: {numbers}")
print(f"\nEven Numbers ({len(even_list)}): {even_list}")
if even_list:
    print(f"  Count:   {len(even_list)}")
    print(f"  Sum:     {sum(even_list)}")
    print(f"  Maximum: {max(even_list)}")
    print(f"  Minimum: {min(even_list)}")

print(f"\nOdd Numbers ({len(odd_list)}): {odd_list}")
if odd_list:
    print(f"  Count:   {len(odd_list)}")
    print(f"  Sum:     {sum(odd_list)}")
    print(f"  Maximum: {max(odd_list)}")
    print(f"  Minimum: {min(odd_list)}")
