# Program 14: Convert a list of strings to a list of integers.

str_list = ["10", "25", "30", "42", "99"]

# Method 1: List comprehension
int_comp = [int(x) for x in str_list]

# Method 2: Using map()
int_map = list(map(int, str_list))

print(f"String list:            {str_list}")
print(f"Integers (comprehension): {int_comp}")
print(f"Integers (map):           {int_map}")
