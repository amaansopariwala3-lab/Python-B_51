
from Employee import Employee

class EmployeeManagement:
    def __init__(self):
        self.employees = []

    def insert(self):
        emp_id = int(input("Enter Employee ID: "))
        name = input("Enter Employee Name: ")
        salary = float(input("Enter Basic Salary: "))

        emp = Employee(emp_id, name, salary)
        emp.calculate_salary()
        self.employees.append(emp)

        print("Employee inserted successfully!")

    def update(self):
        emp_id = int(input("Enter Employee ID to update: "))

        for emp in self.employees:
            if emp.emp_id == emp_id:
                emp.name = input("Enter New Name: ")
                emp.basic_salary = float(input("Enter New Basic Salary: "))
                emp.calculate_salary()
                print("Employee updated successfully!")
                return

        print("Employee not found!")

    def display_all(self):
        if not self.employees:
            print("No employees found!")
            return
        print("\nID  Name  Basic  HRA  DA  PF  Net Salary")
        for emp in self.employees:
            emp.display()

    def calculate_all(self):
        for emp in self.employees:
            emp.calculate_salary()

        print("All employee salaries calculated!")
        self.display_all()

    

management = EmployeeManagement()

while True:
    print("\n===== EMPLOYEE SALARY MENU =====")
    print("1. Insert Employee")
    print("2. Update Employee")
    print("3. Calculate Salary")
    print("4. Display Employees")
    print("5. Exit")

    choice = int(input("Enter your choice: "))

    if choice == 1:
        management.insert()
    elif choice == 2:
        management.update()
    elif choice == 3:
        management.calculate_all()
    elif choice == 4:
        management.display_all()
    elif choice == 5:
        print("Thank you!")
        break
    else:
        print("Invalid choice!")
