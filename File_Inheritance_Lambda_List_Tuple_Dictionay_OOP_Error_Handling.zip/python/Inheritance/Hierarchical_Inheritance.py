class Electricity:
    def __init__(self, name, units):
        self.name = name
        self.units = units

    def display(self):
        print("Customer Name:", self.name)
        print("Units Consumed:", self.units)


class Domestic(Electricity):
    def calculate(self):
        bill = self.units * 5
        print("Domestic Electricity Bill:", bill, "Rs.")


class Commercial(Electricity):
    def calculate(self):
        bill = self.units * 8
        print("Commercial Electricity Bill:", bill, "Rs.")



name = input("Enter customer name: ")
units = int(input("Enter units consumed: "))

print("\n1. Domestic")
print("2. Commercial")
choice = int(input("Enter your choice: "))

if choice == 1:
    obj = Domestic(name, units)
elif choice == 2:
    obj = Commercial(name, units)
else:
    print("Invalid choice")
    exit()

obj.display()
obj.calculate()