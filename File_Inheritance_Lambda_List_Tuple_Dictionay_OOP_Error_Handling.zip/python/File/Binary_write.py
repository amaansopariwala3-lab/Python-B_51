
f = open("employee.txt", "wb")

f.write(b"Employee Salary Management\n")
f.write(("Employee ID: " + input("Enter Employee ID: ") + "\n").encode())
f.write(("Name: " + input("Enter Employee Name: ") + "\n").encode())
f.write(("Basic Salary: " + input("Enter Basic Salary: ") + "\n").encode())

f.close()

print("File created successfully!")
