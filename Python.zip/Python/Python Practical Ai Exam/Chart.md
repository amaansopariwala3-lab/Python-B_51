# PTMAE — Program Flow Tables

**Student:** Aman Sopariwala | **Roll No.:** 51

## 1. Overall program flow

| Step | Action | Next step |
|---|---|---|
| 1 | Start: `python main.py` | 2 |
| 2 | `run_demonstrations()` begins | 3 |
| 3 | Unit 1: `compound_interest`, `calculate_penalty`, `trajectory_guard` | 4 |
| 4 | Unit 2: `parse_raw_log_line`, `create_audit_filter`, `build_positional_filters` | 5 |
| 5 | Unit 3: `build_reverse_index`, `clean_transaction_queue` | 6 |
| 6 | Unit 4: `update_account_record` | 7 |
| 7 | Unit 5: Account classes and `execute_batch_settlement` | 8 |
| 8 | Ask: start CLI? | YES → 9, Enter → 10 |
| 9 | `run_banking_cli()` | 10 |
| 10 | End | — |

## 2. Banking CLI flow

| Step | Action | Next step |
|---|---|---|
| 1 | Show `PTMAE>` prompt and read command | 2 |
| 2 | Check the command | INTEREST → 3, PENALTY → 5, GUARD → 6, HELP → 7, Empty/Unknown → 8, EXIT → 9 |
| 3 | INTEREST: read principal, rate, periods | 4 |
| 4 | Values valid and non-negative? | Yes → print compound interest, back to 1; No → back to 3 |
| 5 | PENALTY: read amount and rate, print penalty fee | 1 |
| 6 | GUARD: run `trajectory_guard` demo and print result | 1 |
| 7 | HELP: show command list | 1 |
| 8 | Show "Please enter a command" or "Unknown command" | 1 |
| 9 | EXIT: quit the CLI | End |

## 3. Trajectory guard flow

| Step | Action | Next step |
|---|---|---|
| 1 | Set `balance = starting_balance` | 2 |
| 2 | More transactions left? | Yes → 3, No → 5 |
| 3 | Termination flag set OR `balance < threshold`? | Yes → 4, No → 3a |
| 3a | `balance = balance + amount`; save balance to history | 2 |
| 4 | Print stop message | 5 |
| 5 | Return `balance`, history | End |

## 4. File update flow (`update_account_record`)

| Step | Action | Next step |
|---|---|---|
| 1 | Open `accounts.db` in `r+` mode | 2 |
| 2 | Read next line | 3 |
| 3 | End of file? | Yes → 9, No → 4 |
| 4 | Parse and validate the record | 5 |
| 5 | Record valid? | Yes → 6, No → 8 |
| 6 | ID matches target and `new_balance >= 0`? | Yes → 7, ID differs → 2, Negative balance → 8 |
| 7 | Shift file tail if length changed, write new record, truncate, append to `ledger.txt` | 2 |
| 8 | Write line number and reason to `corrupted.log` | 2 |
| 9 | Print processed and rejected counts | End |

## 5. Settlement flow (Unit 5)

| Account type | Rule checked | If rule passes | If rule fails |
|---|---|---|---|
| `SavingsAccount` | Balance after settlement ≥ 1000 | SUCCESS, balance reduced | FAILED: `InsufficientBalanceError` |
| `CurrentAccount` | Balance after settlement ≥ −overdraft limit | SUCCESS, balance reduced | FAILED: `InsufficientBalanceError` |
| `CreditAccount` | Used credit + 2.5% surcharge ≤ credit limit | SUCCESS, charged amount returned | FAILED: `InsufficientBalanceError` |

`execute_batch_settlement()` handles each account separately, so one failure does not stop the rest. After the last account it prints the success and failure counts.
