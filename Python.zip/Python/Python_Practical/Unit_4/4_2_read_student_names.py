# 4.2 — Read Student Names
# Reading entire file using 'r' mode and read()

file = open("students.txt", "r")
content = file.read()
file.close()

print("--- Student Names in File ---")
print(content)
