# 4.5 — Student Marks File
# Writing marks of students into a file

file = open("marks.txt", "w")

n = int(input("How many students? "))
for i in range(n):
    name = input(f"Enter student {i + 1} name: ")
    marks = input(f"Enter marks for {name}: ")
    file.write(f"{name}: {marks}\n")

file.close()
print("Marks successfully saved to marks.txt")
