# 4.6 — Append Student
# Appending a new student to an existing file using 'a' mode

file = open("students.txt", "a")

new_name = input("Enter new student name to append: ")
file.write(new_name + "\n")

file.close()
print(f"'{new_name}' appended successfully to students.txt")
