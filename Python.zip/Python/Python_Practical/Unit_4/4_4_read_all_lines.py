# 4.4 — Read All Lines
# Reading all lines as a list using readlines()

file = open("students.txt", "r")
lines = file.readlines()
file.close()

print("List of lines returned by readlines():")
print(lines)

print("\nDisplaying lines one by one:")
for line in lines:
    print(line.strip())
