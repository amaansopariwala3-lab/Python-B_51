# 4.7 — Read and Write Using r+
# Opening file in 'r+' mode for both reading and writing

file = open("students.txt", "r+")

# Read existing content
print("Existing content before write:")
print(file.read())

# Write additional data at the end
new_entry = input("Enter extra entry to add: ")
file.write(new_entry + "\n")

# Seek to beginning to read updated file
file.seek(0)
print("\nUpdated file content:")
print(file.read())

file.close()
