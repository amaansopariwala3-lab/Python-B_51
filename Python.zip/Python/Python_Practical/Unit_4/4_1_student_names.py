# 4.1 — Student Names File
# Writing student names to a file using 'w' mode

file = open("students.txt", "w")

n = int(input("How many students? "))
for i in range(n):
    name = input(f"Enter name of student {i + 1}: ")
    file.write(name + "\n")

file.close()
print("Student names successfully written to students.txt")
