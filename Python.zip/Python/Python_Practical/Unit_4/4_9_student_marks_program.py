# 4.9 — Student Marks Program
# Storing and reading student names and marks in a file

# 1 & 2. Take input and store in file
with open("student_records.txt", "w") as file:
    n = int(input("Enter number of students: "))
    for i in range(n):
        name = input(f"Enter name of student {i + 1}: ")
        marks = input(f"Enter marks of {name}: ")
        file.write(f"{name} - {marks}\n")

print("\n--- Data Saved Successfully ---")

# 3 & 4. Read the file and display stored student marks
print("\n--- Stored Student Marks ---")
with open("student_records.txt", "r") as file:
    for line in file:
        print(line.strip())
