# 4.12 — Complete Exception Handling
# Demonstrating try, multiple except, else, finally, and raise

sample_list = [10, 20, 30]

try:
    print("Current list:", sample_list)
    index = int(input("Enter index to fetch (0-2): "))
    
    if index < 0:
        raise ValueError("Negative index is not allowed!")

    value = sample_list[index]
    divisor = int(input("Enter a number to divide the element by: "))
    result = value / divisor

except IndexError:
    print("IndexError: The index is out of range!")
except ZeroDivisionError:
    print("ZeroDivisionError: Cannot divide by zero!")
except ValueError as e:
    print("ValueError:", e)
else:
    print("Success! Result of division is:", result)
finally:
    print("Finally block: Execution completed.")
