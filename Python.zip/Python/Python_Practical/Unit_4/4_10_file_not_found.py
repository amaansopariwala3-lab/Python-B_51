# 4.10 — FileNotFoundError
# Handling missing file error with try-except

filename = input("Enter filename to open: ")

try:
    file = open(filename, "r")
    content = file.read()
    print("File Content:\n", content)
    file.close()
except FileNotFoundError:
    print(f"Error: The file '{filename}' was not found!")
