# 4.3 — Read One Line
# Reading a file line by line using readline()

file = open("students.txt", "r")

line1 = file.readline()
line2 = file.readline()

print("First line:", line1.strip())
print("Second line:", line2.strip())

file.close()
