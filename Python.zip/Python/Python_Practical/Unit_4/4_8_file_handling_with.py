# 4.8 — File Handling Using with
# Automatic file closing using 'with open()'

# Writing with 'with'
with open("notes.txt", "w") as file:
    file.write("Python Practical Exam\n")
    file.write("Unit 4: File Handling & Exception Handling\n")

# Reading with 'with'
with open("notes.txt", "r") as file:
    data = file.read()

print("File contents (read using 'with'):")
print(data)
