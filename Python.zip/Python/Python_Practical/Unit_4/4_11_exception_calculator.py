# 4.11 — Exception Calculator
# Handling ValueError, ZeroDivisionError, and TypeError

try:
    num1 = float(input("Enter first number: "))
    op = input("Enter operator (+, -, *, /): ")
    num2 = float(input("Enter second number: "))

    if op == "+":
        result = num1 + num2
    elif op == "-":
        result = num1 - num2
    elif op == "*":
        result = num1 * num2
    elif op == "/":
        result = num1 / num2
    else:
        raise TypeError("Invalid operator entered")

    print(f"Result: {result}")

except ValueError:
    print("ValueError: Please enter valid numerical digits!")
except ZeroDivisionError:
    print("ZeroDivisionError: Division by zero is not allowed!")
except TypeError as e:
    print("TypeError:", e)
