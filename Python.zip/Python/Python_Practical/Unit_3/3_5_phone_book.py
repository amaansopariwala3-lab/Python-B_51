# 3.5 Phone Book
phone_book = {}

# (a) Add 5 contacts
phone_book["Aarav"] = "9876543210"
phone_book["Diya"] = "9823456781"
phone_book["Karan"] = "9812345678"
phone_book["Meera"] = "9898765432"
phone_book["Rohan"] = "9867543210"
print("(a) 5 Contacts added successfully.")

# (b) Search by name
name = "Diya"
print(f"(b) Search '{name}':", phone_book.get(name, "Contact not found"))

# (c) Update a number
phone_book["Karan"] = "9999999999"
print("(c) Updated Karan's number to:", phone_book["Karan"])

# (d) Delete a contact
deleted = phone_book.pop("Rohan", None)
print(f"(d) Deleted contact 'Rohan': {deleted}")

# (e) Display all contacts sorted by name
print("(e) All contacts sorted by name:")
for contact in sorted(phone_book.keys()):
    print(f"  {contact}: {phone_book[contact]}")
