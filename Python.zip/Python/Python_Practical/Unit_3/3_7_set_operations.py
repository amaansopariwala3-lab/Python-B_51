# 3.7 Set Operations Lab
set1 = {x for x in range(1, 16) if x % 2 != 0}  # odd numbers 1-15
set2 = {x for x in range(1, 16) if x % 3 == 0}  # multiples of 3 up to 15

print("Set 1 (Odd 1-15):", set1)
print("Set 2 (Multiples of 3):", set2)

print("\nUnion:", set1 | set2)
print("Intersection:", set1 & set2)
print("Difference (set1 - set2):", set1 - set2)
print("Difference (set2 - set1):", set2 - set1)
print("Symmetric Difference:", set1 ^ set2)
