# 3.8 2D Matrix (Nested List)
matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

# (a) Display in tabular format
print("(a) Matrix in tabular format:")
for row in matrix:
    for val in row:
        print(f"{val:4}", end="")
    print()

# (b) Calculate sum of each row
print("\n(b) Sum of each row:")
for idx, row in enumerate(matrix, start=1):
    print(f"Row {idx} sum = {sum(row)}")

# (c) Calculate sum of main diagonal
diagonal_sum = sum(matrix[i][i] for i in range(len(matrix)))
print(f"\n(c) Sum of main diagonal = {diagonal_sum}")
