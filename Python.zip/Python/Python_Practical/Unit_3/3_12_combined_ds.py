# 3.12 Combined DS Program
# Each task = {'task': string, 'tags': set}
todo_list = []

def add_task(task_name, tags):
    todo_list.append({"task": task_name, "tags": set(tags)})
    print(f"Task added: '{task_name}' with tags {set(tags)}")

def display_all():
    print("\n--- All To-Do Tasks ---")
    for idx, item in enumerate(todo_list, start=1):
        tags_str = ", ".join(item["tags"])
        print(f"{idx}. {item['task']} [Tags: {tags_str}]")

def find_by_tag(search_tag):
    print(f"\n--- Tasks with tag '{search_tag}' ---")
    found = False
    for item in todo_list:
        if search_tag in item["tags"]:
            print(f"- {item['task']}")
            found = True
    if not found:
        print("No tasks found with this tag.")

# Simulation
add_task("Submit Assignment", ["college", "urgent"])
add_task("Buy groceries", ["personal", "shopping"])
add_task("Prepare Practical Exam", ["college", "study"])

display_all()
find_by_tag("college")
find_by_tag("personal")
