# 3.2 Stack Simulator
stack = []

def push(item):
    stack.append(item)
    print(f"Pushed: {item}")

def pop():
    if is_empty():
        print("Stack is empty (Underflow)")
        return None
    return stack.pop()

def peek():
    if is_empty():
        return None
    return stack[-1]

def is_empty():
    return len(stack) == 0

def display():
    print("Current Stack:", stack)

# Simulation: push 5 items, peek, pop 2, display
push(10)
push(20)
push(30)
push(40)
push(50)

print("Peek item:", peek())
print("Popped:", pop())
print("Popped:", pop())
display()
