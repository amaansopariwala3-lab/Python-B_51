# 3.3 List Comprehension Lab
# (a) squares of 1-20
squares = [x ** 2 for x in range(1, 21)]
print("(a) Squares 1-20:\n", squares)

# (b) even numbers 1-50
evens = [x for x in range(1, 51) if x % 2 == 0]
print("\n(b) Even numbers 1-50:\n", evens)

# (c) words from a sentence longer than 4 characters
sentence = "Python is a powerful language that makes programming enjoyable"
long_words = [w for w in sentence.split() if len(w) > 4]
print("\n(c) Words longer than 4 characters:\n", long_words)

# (d) cubes of odd numbers 1-15
odd_cubes = [x ** 3 for x in range(1, 16) if x % 2 != 0]
print("\n(d) Cubes of odd numbers 1-15:\n", odd_cubes)
