# 3.10 Duplicate Remover
nums = [4, 2, 7, 2, 4, 9, 1, 7, 5, 4]
print("Original List:", nums)

# (a) Remove duplicates using set
unique_nums = list(set(nums))
print("(a) List after removing duplicates:", unique_nums)

# (b) Find elements present in list 1 but not list 2
list1 = [1, 2, 3, 4, 5]
list2 = [3, 4, 6, 7]
diff = list(set(list1) - set(list2))
print("(b) Elements in list1 but not list2:", diff)

# (c) Count how many times each number appears
counts = {x: nums.count(x) for x in set(nums)}
print("(c) Frequency count of each number:", counts)
