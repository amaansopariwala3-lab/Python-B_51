# 3.1 List Statistics
n = int(input("How many numbers? "))
nums = []
for i in range(n):
    val = float(input(f"Enter number {i + 1}: "))
    nums.append(val)

print("(a) List:", nums)
print("(b) Sorted list:", sorted(nums))
print("(c) Reversed list:", list(reversed(nums)))
print("(d) Max:", max(nums))
print("(e) Min:", min(nums))
print("(f) Sum:", sum(nums))
print("(g) Average:", sum(nums) / len(nums) if nums else 0)
