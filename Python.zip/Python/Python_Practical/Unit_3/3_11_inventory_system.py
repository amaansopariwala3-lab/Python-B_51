# 3.11 Inventory System
inventory = {}

def add_item(product, qty):
    inventory[product] = inventory.get(product, 0) + qty
    print(f"Added {qty} of '{product}'.")

def remove_item(product):
    if product in inventory:
        del inventory[product]
        print(f"Removed '{product}'.")
    else:
        print(f"'{product}' not found in inventory.")

def update_qty(product, qty):
    if product in inventory:
        inventory[product] = qty
        print(f"Updated '{product}' quantity to {qty}.")
    else:
        print(f"'{product}' not found in inventory.")

def display_inventory():
    print("\n--- Current Inventory ---")
    for prod, qty in inventory.items():
        print(f"{prod}: {qty}")

def low_stock():
    print("\n--- Low Stock Items (< 5) ---")
    low_items = {prod: qty for prod, qty in inventory.items() if qty < 5}
    if low_items:
        for prod, qty in low_items.items():
            print(f"{prod}: {qty}")
    else:
        print("No low stock items.")

# Simulation
add_item("Notebook", 15)
add_item("Pen", 4)
add_item("Pencil", 2)
add_item("Eraser", 10)
display_inventory()

update_qty("Notebook", 12)
remove_item("Eraser")
low_stock()
display_inventory()
