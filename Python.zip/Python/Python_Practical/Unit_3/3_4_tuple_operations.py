# 3.4 Tuple Operations
marks = (85, 90, 78, 92, 88)

# Indexing, slicing, len()
print("Original Tuple:", marks)
print("First element (index 0):", marks[0])
print("Slice [1:4]:", marks[1:4])
print("Length of tuple:", len(marks))

# Unpacking
m1, m2, m3, m4, m5 = marks
print(f"Unpacked: {m1}, {m2}, {m3}, {m4}, {m5}")

# Min, max, avg
print(f"Min: {min(marks)}, Max: {max(marks)}, Avg: {sum(marks) / len(marks)}")

# Try modifying - show TypeError
try:
    marks[0] = 95
except TypeError as e:
    print("Modifying tuple directly raised TypeError:", e)

# Convert to list, modify, convert back
marks_list = list(marks)
marks_list[0] = 95
marks = tuple(marks_list)
print("Tuple after converting to list, modifying, and converting back:", marks)
