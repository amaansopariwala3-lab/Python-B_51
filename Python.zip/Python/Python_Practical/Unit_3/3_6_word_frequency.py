# 3.6 Word Frequency Counter
text = "python is simple python is easy learning python is fun"
words = text.lower().split()

freq = {}
for w in words:
    freq[w] = freq.get(w, 0) + 1

# Display words sorted by frequency (most common first)
sorted_freq = sorted(freq.items(), key=lambda item: item[1], reverse=True)

print("Words sorted by frequency (most common first):")
for word, count in sorted_freq:
    print(f"{word}: {count}")
