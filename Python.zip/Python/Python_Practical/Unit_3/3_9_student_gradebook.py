# 3.9 Student Gradebook
gradebook = {
    "Aarav": [85, 90, 88],
    "Diya": [92, 95, 94],
    "Karan": [70, 75, 72],
    "Meera": [88, 84, 91]
}

# Calculate average for each student
averages = {name: sum(marks) / len(marks) for name, marks in gradebook.items()}

# Display sorted by average (highest first)
sorted_students = sorted(averages.items(), key=lambda x: x[1], reverse=True)

print("Student Gradebook (Sorted by Average):")
for name, avg in sorted_students:
    print(f"{name}: {avg:.2f}")

top_student = sorted_students[0]
print(f"\nTop Student: {top_student[0]} with average {top_student[1]:.2f}")
