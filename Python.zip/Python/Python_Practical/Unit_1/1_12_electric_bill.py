# 1.12 Electric Bill Calculator
prev = float(input("Enter previous meter reading: "))
curr = float(input("Enter current meter reading: "))

units = curr - prev
fixed_charge = 100
bill = (units * 5.50) + fixed_charge

print("Units Consumed:", units)
print("Total Bill: Rs.", bill)
