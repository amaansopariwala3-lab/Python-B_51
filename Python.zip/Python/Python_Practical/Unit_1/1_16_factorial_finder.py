# 1.16 Factorial Finder
n = int(input("Enter a number N: "))

fact = 1
for i in range(1, n + 1):
    fact *= i

print(f"Factorial of {n} ({n}!) = {fact}")
