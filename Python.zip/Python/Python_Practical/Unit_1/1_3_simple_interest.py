# 1.3 Simple Interest Calculator
p = float(input("Enter Principal (P): "))
r = float(input("Enter Rate of Interest (R): "))
t = float(input("Enter Time in years (T): "))

si = (p * r * t) / 100
total_amount = p + si

print("Simple Interest (SI):", si)
print("Total Amount (P + SI):", total_amount)
