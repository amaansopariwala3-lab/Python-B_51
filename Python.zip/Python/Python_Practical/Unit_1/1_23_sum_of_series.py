# 1.23 Sum of Series
n = int(input("Enter N: "))

sum_n = 0
sum_sq = 0
sum_cube = 0

for i in range(1, n + 1):
    sum_n += i
    sum_sq += i ** 2
    sum_cube += i ** 3

print(f"(a) Sum of first {n} natural numbers: {sum_n}")
print(f"(b) Sum of squares: {sum_sq}")
print(f"(c) Sum of cubes: {sum_cube}")
