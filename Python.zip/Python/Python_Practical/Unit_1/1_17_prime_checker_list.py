# 1.17 Prime Number Checker & List
# (a) Check if a number is prime
num = int(input("Enter a number to check prime: "))
if num > 1:
    is_prime = True
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            is_prime = False
            break
    if is_prime:
        print(f"{num} is Prime")
    else:
        print(f"{num} is Not Prime")
else:
    print(f"{num} is Not Prime")

# (b) Print all prime numbers from 2 to N
n = int(input("\nEnter N to print primes up to N: "))
print(f"Prime numbers from 2 to {n}:")
for val in range(2, n + 1):
    for i in range(2, val):
        if val % i == 0:
            break
    else:
        print(val, end=" ")
print()
