# 1.22 ATM PIN Simulator
CORRECT_PIN = "1234"
attempts = 3

while attempts > 0:
    pin = input("Enter your 4-digit PIN: ")
    if pin == CORRECT_PIN:
        print("Access Granted")
        break
    else:
        attempts -= 1
        print(f"Incorrect PIN. Attempts left: {attempts}")
else:
    print("Card Blocked")
