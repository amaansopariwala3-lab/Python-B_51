# 1.13 Number Classifier
num = int(input("Enter an integer: "))

# (a) positive/negative/zero
if num > 0:
    print("(a) Number is Positive")
elif num < 0:
    print("(a) Number is Negative")
else:
    print("(a) Number is Zero")

# (b) even or odd
if num % 2 == 0:
    print("(b) Number is Even")
else:
    print("(b) Number is Odd")

# (c) divisible by 5 or not
if num % 5 == 0:
    print("(c) Number is Divisible by 5")
else:
    print("(c) Number is Not divisible by 5")
