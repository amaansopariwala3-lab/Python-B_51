# 1.9 Swap Without Temp
a = int(input("Enter first number (a): "))
b = int(input("Enter second number (b): "))
print(f"Before swap: a = {a}, b = {b}")

# Swap using Python tuple
a, b = b, a
print(f"After tuple swap: a = {a}, b = {b}")

# Arithmetic swap back
a = a + b
b = a - b
a = a - b
print(f"After arithmetic swap: a = {a}, b = {b}")
