# 1.6 Salary Calculator
basic = float(input("Enter basic salary: "))

hra = 0.20 * basic
da = 0.10 * basic
pf = 0.12 * basic

gross = basic + hra + da
net = gross - pf

print("Gross Salary:", gross)
print("Net Salary:", net)
