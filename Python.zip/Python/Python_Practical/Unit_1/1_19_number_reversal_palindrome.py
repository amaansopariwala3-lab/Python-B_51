# 1.19 Number Reversal & Palindrome
num = int(input("Enter a number: "))
temp = num
rev = 0

while temp > 0:
    digit = temp % 10
    rev = rev * 10 + digit
    temp //= 10

print("Reversed Number:", rev)
if num == rev:
    print("It is a Palindrome number.")
else:
    print("It is Not a Palindrome number.")
