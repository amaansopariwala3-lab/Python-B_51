# 1.1 Hello World & Intro
print("Name: Aman Sopariwala")
print("Roll Number: 51")
print("Programme: M.Sc. IT")
print("Semester: 1st Semester")
