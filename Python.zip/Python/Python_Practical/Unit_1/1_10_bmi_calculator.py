# 1.10 BMI Calculator
weight = float(input("Enter weight in kg: "))
height = float(input("Enter height in metres: "))

bmi = weight / (height ** 2)
print("BMI:", round(bmi, 2))

if bmi < 18.5:
    print("Category: Underweight")
elif 18.5 <= bmi <= 24.9:
    print("Category: Normal")
elif 25 <= bmi <= 29.9:
    print("Category: Overweight")
else:
    print("Category: Obese")
