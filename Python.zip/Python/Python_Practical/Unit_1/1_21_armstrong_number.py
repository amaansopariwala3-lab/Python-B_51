# 1.21 Armstrong Number Finder
# Check if single number is Armstrong
num = int(input("Enter a 3-digit number to check Armstrong: "))
temp = num
total = 0
while temp > 0:
    d = temp % 10
    total += d ** 3
    temp //= 10

if total == num:
    print(f"{num} is an Armstrong number.")
else:
    print(f"{num} is Not an Armstrong number.")

# Print all Armstrong numbers between 1 and 999
print("\nArmstrong numbers between 1 and 999:")
for n in range(1, 1000):
    s = sum(int(digit) ** 3 for digit in str(n))
    if s == n:
        print(n, end=" ")
print()
