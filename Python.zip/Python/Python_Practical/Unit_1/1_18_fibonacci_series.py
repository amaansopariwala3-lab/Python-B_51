# 1.18 Fibonacci Series
n = int(input("Enter number of terms N: "))

a, b = 0, 1
count = 0

print("Fibonacci series:")
while count < n:
    print(a, end=" ")
    a, b = b, a + b
    count += 1
print()
