# 1.20 Star Pattern Collection
print("(a) Right-angled triangle (5 rows):")
for i in range(1, 6):
    for j in range(1, i + 1):
        print("*", end=" ")
    print()

print("\n(b) Inverted triangle (5 rows):")
for i in range(5, 0, -1):
    for j in range(1, i + 1):
        print("*", end=" ")
    print()

print("\n(c) Diamond pattern (5 rows):")
# Upper half
for i in range(1, 6):
    for s in range(5 - i):
        print(" ", end="")
    for j in range(i):
        print("* ", end="")
    print()
# Lower half
for i in range(4, 0, -1):
    for s in range(5 - i):
        print(" ", end="")
    for j in range(i):
        print("* ", end="")
    print()
