# 1.5 Area & Perimeter
length = float(input("Enter length: "))
breadth = float(input("Enter breadth: "))

area_rect = length * breadth
perimeter_rect = 2 * (length + breadth)
area_circle = 3.14159 * (length ** 2)

print("Area of Rectangle:", area_rect)
print("Perimeter of Rectangle:", perimeter_rect)
print("Area of Circle (radius = length):", area_circle)
