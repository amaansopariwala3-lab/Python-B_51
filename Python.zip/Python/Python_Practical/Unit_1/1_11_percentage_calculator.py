# 1.11 Percentage Calculator
m1 = float(input("Enter marks of subject 1: "))
m2 = float(input("Enter marks of subject 2: "))
m3 = float(input("Enter marks of subject 3: "))
m4 = float(input("Enter marks of subject 4: "))
m5 = float(input("Enter marks of subject 5: "))

total = m1 + m2 + m3 + m4 + m5
percentage = (total / 500) * 100
average = total / 5

print("Total Marks:", total)
print("Percentage:", percentage, "%")
print("Average Marks:", average)
