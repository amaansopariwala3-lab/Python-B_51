# 2.1 Function Basics
def greet(name):
    print(f"Hello, {name}!")

def square(n):
    return n ** 2

def cube(n):
    return n ** 3

# Call each function 3 times
greet("Alice")
greet("Bob")
greet("Charlie")

print("Square of 2:", square(2))
print("Square of 4:", square(4))
print("Square of 6:", square(6))

print("Cube of 2:", cube(2))
print("Cube of 3:", cube(3))
print("Cube of 4:", cube(4))
