# 2.6 Vowel Counter & Character Frequency
def count_vowels(s):
    vowels = "aeiouAEIOU"
    return sum(1 for ch in s if ch in vowels)

def char_frequency(s):
    freq = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    return freq

sentence = "Python Programming is fun and versatile"
print("Sentence:", sentence)
print("Vowel Count:", count_vowels(sentence))
print("Character Frequency:", char_frequency(sentence))
