# 2.5 String Reverse & Palindrome
def reverse_string(s):
    return s[::-1]

def is_palindrome(s):
    return s.lower() == reverse_string(s).lower()

# Test words
test_words = ["madam", "racecar", "Tanveer", "Ahmedabad"]
for word in test_words:
    print(f"Word: '{word}' | Reversed: '{reverse_string(word)}' | Palindrome: {is_palindrome(word)}")
