# 2.10 Report Card with f-strings
student_name = "Aman Sopariwala"
roll_no = 51
marks_5_subjects = [85, 90, 78, 92, 88]

total = sum(marks_5_subjects)
percentage = total / len(marks_5_subjects)

if percentage >= 90:
    grade = "A+"
elif percentage >= 80:
    grade = "A"
elif percentage >= 70:
    grade = "B"
else:
    grade = "C"

print("=" * 40)
print(f"{'REPORT CARD':^40}")
print("=" * 40)
print(f"{'Student Name:':<15}{student_name}")
print(f"{'Roll No:':<15}{roll_no}")
print("-" * 40)
for idx, mark in enumerate(marks_5_subjects, start=1):
    print(f"Subject {idx}:{'':<10}{mark:>5}")
print("-" * 40)
print(f"{'Total Marks:':<15}{total:>5} / 500")
print(f"{'Percentage:':<15}{percentage:>5.2f}%")
print(f"{'Grade:':<15}{grade:>5}")
print("=" * 40)
