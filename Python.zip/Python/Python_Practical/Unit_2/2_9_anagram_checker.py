# 2.9 Anagram Checker
def is_anagram(s1, s2):
    return sorted(s1.lower().replace(" ", "")) == sorted(s2.lower().replace(" ", ""))

# Test 4 pairs
test_pairs = [
    ("listen", "silent"),
    ("triangle", "integral"),
    ("apple", "pale"),
    ("evil", "vile")
]

for s1, s2 in test_pairs:
    print(f"'{s1}' and '{s2}' are anagrams? {is_anagram(s1, s2)}")
