# 2.4 Multi-Return Function
def stats(a, b, c):
    total = a + b + c
    avg = total / 3
    minimum = min(a, b, c)
    maximum = max(a, b, c)
    return total, avg, minimum, maximum

# Unpack and display all 4 results
s, a, mn, mx = stats(10, 25, 15)
print("Sum:", s)
print("Average:", round(a, 2))
print("Minimum:", mn)
print("Maximum:", mx)
