# 2.3 Factorial Function
def factorial(n):
    fact = 1
    for i in range(1, n + 1):
        fact *= i
    return fact

print(f"{'Number':<10}{'Factorial':<15}")
print("-" * 25)
for i in range(1, 11):
    print(f"{i:<10}{factorial(i):<15}")
