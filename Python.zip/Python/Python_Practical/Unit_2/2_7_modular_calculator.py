# 2.7 Modular Calculator
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    try:
        return a / b
    except ZeroDivisionError:
        return "Error: Division by zero is not allowed."

def power(a, b):
    return a ** b

print("--- Calculator Menu ---")
print("1. Add\n2. Subtract\n3. Multiply\n4. Divide\n5. Power")
choice = input("Enter choice (1-5): ")

n1 = float(input("Enter first number: "))
n2 = float(input("Enter second number: "))

if choice == "1":
    print("Result:", add(n1, n2))
elif choice == "2":
    print("Result:", subtract(n1, n2))
elif choice == "3":
    print("Result:", multiply(n1, n2))
elif choice == "4":
    print("Result:", divide(n1, n2))
elif choice == "5":
    print("Result:", power(n1, n2))
else:
    print("Invalid choice.")
