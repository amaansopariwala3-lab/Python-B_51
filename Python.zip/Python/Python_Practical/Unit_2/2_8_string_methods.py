# 2.8 String Methods Practice
sentence = input("Enter a sentence: ")

print("(a) upper():", sentence.upper())
print("(b) lower():", sentence.lower())
print("(c) title():", sentence.title())
print("(d) strip():", sentence.strip())
print("(e) split():", sentence.split())
print("(f) replace spaces:", sentence.replace(" ", "_"))
print("(g) find('a'):", sentence.find("a"))
