# 2.11 Default Parameter Function
def display_info(name, city="Ahmedabad", programme="M.Sc. IT"):
    print(f"Name: {name} | City: {city} | Programme: {programme}")

# (a) with all 3 args
display_info("Rohan", "Mumbai", "MCA")

# (b) with only name
display_info("Priya")

# (c) with name and city
display_info("Aman", "Surat")
