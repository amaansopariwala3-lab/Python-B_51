# 2.12 Lambda Sort
students = [
    ("Neha", 75),
    ("Rahul", 55),
    ("Ananya", 92),
    ("Dev", 48),
    ("Pooja", 84)
]

# Sort by marks descending using lambda
sorted_students = sorted(students, key=lambda x: x[1], reverse=True)
print("Sorted students (descending):", sorted_students)

# Filter students with marks >= 60
passed_students = list(filter(lambda x: x[1] >= 60, sorted_students))
print("Students with marks >= 60:", passed_students)
