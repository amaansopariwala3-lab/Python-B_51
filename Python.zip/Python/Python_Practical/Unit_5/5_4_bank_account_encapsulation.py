# 5.4 — BankAccount with Encapsulation
# Data hiding using private attribute __balance and getter/setter methods

class BankAccount:
    def __init__(self, account_holder, initial_balance=0):
        self.account_holder = account_holder
        self.__balance = initial_balance    # Private attribute

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print(f"Deposited: Rs. {amount}")
        else:
            print("Invalid deposit amount!")

    def withdraw(self, amount):
        if 0 < amount <= self.__balance:
            self.__balance -= amount
            print(f"Withdrawn: Rs. {amount}")
        else:
            print("Invalid or insufficient funds for withdrawal!")

    def get_balance(self):                  # Getter method
        return self.__balance

# Demonstration
account = BankAccount("Aman Sopariwala", 1000)
print(f"Initial Balance: Rs. {account.get_balance()}")

account.deposit(500)
account.withdraw(300)
account.withdraw(2000)   # Invalid withdrawal attempt
print(f"Final Balance: Rs. {account.get_balance()}")
