# 5.9 — Basic Polymorphism
# Calling the same method name on different class objects

class Dog:
    def sound(self):
        return "Bark! Bark!"

class Cat:
    def sound(self):
        return "Meow! Meow!"

class Cow:
    def sound(self):
        return "Moo! Moo!"

# Common interface / loop demonstrating polymorphism
animals = [Dog(), Cat(), Cow()]

for animal in animals:
    print(animal.sound())
