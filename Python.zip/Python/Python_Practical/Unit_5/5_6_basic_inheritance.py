# 5.6 — Basic Inheritance
# Parent class and child class inheritance

class Animal:
    def sound(self):
        print("Animals make different sounds.")

class Dog(Animal):    # Dog inherits from Animal
    def bark(self):
        print("Dog barks: Woof! Woof!")

# Demonstration
d = Dog()
d.sound()   # Inherited method from Animal
d.bark()    # Method of Dog
