# 5.8 — Method Overriding
# Child classes overriding parent class method

class Animal:
    def sound(self):
        print("Generic animal sound")

class Dog(Animal):
    def sound(self):                  # Overriding sound()
        print("Dog says: Woof! Woof!")

class Cat(Animal):
    def sound(self):                  # Overriding sound()
        print("Cat says: Meow! Meow!")

# Demonstration
dog = Dog()
cat = Cat()

dog.sound()
cat.sound()
