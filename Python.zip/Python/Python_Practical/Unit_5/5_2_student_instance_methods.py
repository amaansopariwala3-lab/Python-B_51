# 5.2 — Student Instance Methods
# Defining and calling instance methods

class Student:
    def __init__(self, name, roll_no, marks):
        self.name = name
        self.roll_no = roll_no
        self.marks = marks

    def display(self):
        print(f"Name: {self.name} | Roll No: {self.roll_no} | Marks: {self.marks}")

# Creating two student objects
s1 = Student("Rohan", 103, 85)
s2 = Student("Priya", 104, 92)

# Calling instance method
s1.display()
s2.display()
