# 5.5 — Public, Protected, and Private Attributes
# Demonstrating access control in Python using a Student class

class Student:
    def __init__(self, name, roll_no, marks):
        self.name = name          # Public attribute
        self._roll_no = roll_no   # Protected attribute (single underscore)
        self.__marks = marks      # Private attribute (double underscore)

    # Method to access private attribute from within the class
    def show_private(self):
        print(f"Private Marks (accessed via method): {self.__marks}")


# 1. Create an object of Student
s = Student("Aman Sopariwala", 51, 95)

# 2. Accessing Public attribute directly
print("Public Name:", s.name)

# 3. Accessing Protected attribute directly
print("Protected Roll No:", s._roll_no)

# 4. Accessing Private attribute using class method
s.show_private()
