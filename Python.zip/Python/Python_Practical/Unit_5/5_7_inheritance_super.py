# 5.7 — Inheritance Using super()
# Calling parent constructor using super()

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

class Student(Person):
    def __init__(self, name, age, roll_no):
        super().__init__(name, age)   # Calling parent constructor
        self.roll_no = roll_no

    def display(self):
        print(f"Name: {self.name} | Age: {self.age} | Roll No: {self.roll_no}")

# Demonstration
s = Student("Karan", 21, 107)
s.display()
