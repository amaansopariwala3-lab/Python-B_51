# 5.1 — Student Class
# Defining a class, constructor, and creating objects

class Student:
    def __init__(self, name, roll_no, course):
        self.name = name          # Instance attribute
        self.roll_no = roll_no    # Instance attribute
        self.course = course      # Instance attribute

# Creating student objects
s1 = Student("Aarav", 101, "M.Sc. IT")
s2 = Student("Diya", 102, "M.Sc. IT")

# Displaying object details
print(f"Student 1: Name = {s1.name}, Roll No = {s1.roll_no}, Course = {s1.course}")
print(f"Student 2: Name = {s2.name}, Roll No = {s2.roll_no}, Course = {s2.course}")
