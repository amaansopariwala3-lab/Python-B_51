# 5.3 — Class Attribute
# Demonstrating class attribute shared among all instances

class Student:
    college = "LJ University"   # Class attribute (shared)

    def __init__(self, name, roll_no):
        self.name = name             # Instance attribute
        self.roll_no = roll_no       # Instance attribute

# Creating multiple objects
s1 = Student("Aman", 105)
s2 = Student("Meera", 106)

# Accessing class attribute via objects and class name
print(f"{s1.name} studies at: {s1.college}")
print(f"{s2.name} studies at: {s2.college}")
print(f"College from class itself: {Student.college}")
