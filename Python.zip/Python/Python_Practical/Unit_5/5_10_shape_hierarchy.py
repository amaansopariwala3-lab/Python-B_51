# 5.10 — Shape Hierarchy
# Inheritance, method overriding, and polymorphism

class Shape:
    def area(self):
        return 0

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14159 * (self.radius ** 2)

class Rectangle(Shape):
    def __init__(self, length, breadth):
        self.length = length
        self.breadth = breadth

    def area(self):
        return self.length * self.breadth

class Triangle(Shape):
    def __init__(self, base, height):
        self.base = base
        self.height = height

    def area(self):
        return 0.5 * self.base * self.height

# Polymorphic demonstration
shapes = [
    Circle(5),
    Rectangle(4, 6),
    Triangle(3, 8)
]

for s in shapes:
    print(f"Area of {s.__class__.__name__}: {s.area():.2f}")
