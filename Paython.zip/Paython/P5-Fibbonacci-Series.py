#Fibbonacci Series upto N
no = int(input('Enter the Number :'))
a=1
b=1
c=None

print(a, end=" ")
print(b, end=" ")
while 1:
    c=a+b
    a=b
    b=c
    if(c > no) :
        c = 2  
        break
    else :
        print(c, end=" ")