name = input("Enter the Name of Student :")
marks = int(input("enter the Student Marks :"))


if marks >= 90 :
    print(" Grade A :",marks)
elif marks >= 80 :
    print(" Grade A :",marks)
elif marks >= 70 :
    print(" Grade A :",marks)
elif marks >= 60 :
    print(" Grade A :",marks)
else :
    print("fail :",marks)
