
for i in range(11,0,-1) :
    print(i)

    # range(1,5) 1 to 5
    # range(11,0)  10 ,9 ,8 to 1 
    # range(20,10,-2) 20 , 18 ,16 to 12
    # range(1,20,3) 1 3 6 9 12 to 20  