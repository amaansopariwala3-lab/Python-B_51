#Nested loop 
for i in range(1,6) :
    for j in range(1,i+1) :
        print(j,end=" ")  # Changed j to i output will 1 22 333 4444
    print()