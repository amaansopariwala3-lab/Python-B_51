Unit = int(input("Enter the Used the Unit :"))
bill_am = int()


if  Unit <= 100 :
            bill_am = (Unit*2)
elif Unit <=200 :
        bill_am = 200 +((Unit-100)*3)
elif Unit <=300 :
        bill_am = 200+300 +((Unit-200)*4)
else :
        bill_am = 200+300+400 +((Unit-300)*7)

        print("Total Bill :",bill_am)