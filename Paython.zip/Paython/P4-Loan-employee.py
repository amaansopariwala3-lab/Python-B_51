name = input("Enter the Name of Employees :")
income = int(input("enter the Employees Income :"))


if income >= 100000 :
    print("  Premium Loan :",income)
elif income >= 50000 :
    print(" Standard Loan :",income)
elif income >= 25000 :
    print(" Basic Loan :",income)

else :
    print("Not Eligible :",income)
