n = int(input("Enter the Number : "))
cnt =0
for i in range(1,n+1) :
    if(n%i==0):
        cnt += 1
    if (cnt>2) :
        break;
print("Count the number Mul :",cnt)
if(cnt==2) :
    print("Prime No:",n)
else :
    print("Not Prime No . :",n)
