 # 234 Revers 432
no = int(input("Enter the Number :"))
rem =0

while (no > 0) :
    rem =(rem*10)+no%10
    no=no//10

print(rem)

