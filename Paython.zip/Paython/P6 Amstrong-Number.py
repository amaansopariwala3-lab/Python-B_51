#Amstrong Number 
no = int(input("Enter the Number :"))
rem =None
temp = no
sum =0 
while no > 0 :
    rem=no % 10
    sum=sum+(rem*rem*rem)
    no=no//10
print(sum)
if(temp == sum) :
    print("Number is Amstrong :",sum)
else : 
    print("Number is not Amstrong: ",sum)
